import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const {build}=require('esbuild') as typeof import('esbuild');
test('actual bundled capture entries contain same fixed shared worker and no legacy/db/employee/provider SDK runtime',async()=>{for(const action of ['create','leave','retrieve-pre-stop','retrieve-post-stop']){const result=await build({entryPoints:[fileURLToPath(new URL(`./src/trigger/oracle2-meeting-capture-${action}.ts`,import.meta.url))],bundle:true,write:false,platform:'node',format:'esm',target:'node24',external:['@trigger.dev/sdk/v3'],metafile:true,logLevel:'silent'});const inputs=Object.keys(result.metafile!.inputs);assert.ok(inputs.some(p=>p.endsWith('shared/src/protected-meeting-worker.ts')));assert.ok(inputs.some(p=>p.endsWith('shared/src/protected-service-channel.ts')));assert.ok(inputs.some(p=>p.endsWith('shared/src/recall-capture-contract.ts')));assert.ok(!inputs.some(p=>/packages\/(db|auth|ai)\/|apps\/web\/|src\/lib\/recall\.ts|oracle2-python|legacy/i.test(p)));assert.equal(result.outputFiles!.length,1);assert.match(result.outputFiles![0]!.text,/maxAttempts: 1/);assert.ok(!result.outputFiles![0]!.text.includes('SUPABASE_SERVICE_ROLE_KEY'));}});
