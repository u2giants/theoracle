import {task} from '@trigger.dev/sdk/v3';
import {runInstalledMeetingNormalizationV1} from '../lib/meeting-normalization';
export const oracle2MeetingIngressNormalizeV1=task({
 id:'oracle2-meeting-ingress-normalize-v1',maxDuration:30,retry:{maxAttempts:1},
 run:async(raw:unknown)=>runInstalledMeetingNormalizationV1(raw),
});
