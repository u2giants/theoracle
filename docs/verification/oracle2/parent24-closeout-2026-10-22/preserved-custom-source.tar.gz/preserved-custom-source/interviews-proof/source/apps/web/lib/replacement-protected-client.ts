/** Server-only, fixed-peer control transport. No admission, retries, result API,
 * writer capability or fixture fallback. Used by the protected control route. */
import * as https from 'node:https';
import * as tls from 'node:tls';
import { performance } from 'node:perf_hooks';
import { canonicalHash, canonicalJson, canonicalUuid, instant, matchesIdentity, parseClosedJson, readInstalledBinding, readInstalledViewerBinding, readInstalledUploadBinding, readInstalledConversationBinding, MAX_ORIGINAL_BYTES, sha256, type InstalledBinding, type ProtectedBinding, type ViewerSourcePin } from './replacement-server-binding';
import { parseConversationResponse,validateConversationRequest,type ConversationPacket } from './replacement-conversation-contract';
import { isConversationPath,readControlWindow, unavailableControl, privateControlHeaders } from './replacement-control-window';
if (typeof window !== 'undefined') throw new Error('Replacement control unavailable');
const failure = (): never => { throw new Error('Replacement control unavailable'); };
const exact = (v: unknown, fields: readonly string[]): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v) && Object.keys(v).length === fields.length && fields.every(k => Object.hasOwn(v,k));
const integer = (v: unknown): v is number => typeof v === 'number' && Number.isInteger(v) && v >= 1 && v <= 2147483647;
export interface ControlMetadata {
  readonly runId: string; readonly journeyRevision: number; readonly controlState: 'pending'|'processing'|'delivered'|'revision_pending'|'cancelled'|'error'|'awaiting-external-authority'|'missing-evidence'|'cancel-requested'|'failed'|'UNKNOWN';
  readonly populationSha256: string; readonly cancelRequested: boolean; readonly remoteStopProven: false; readonly resultAvailable: false;
}
const states = new Set(['pending','processing','delivered','revision_pending','cancelled','error','awaiting-external-authority','missing-evidence','cancel-requested','failed','UNKNOWN']);
/** Descriptive wire validation; a valid DTO grants no access. */
export function parseControlMetadata(bytes: Uint8Array): Readonly<ControlMetadata> {
  const v = parseClosedJson(bytes,4096);
  if (canonicalJson(v) !== Buffer.from(bytes).toString('utf8') || !exact(v,['runId','journeyRevision','controlState','populationSha256','cancelRequested','remoteStopProven','resultAvailable']) || !canonicalUuid(v.runId) || !integer(v.journeyRevision) || typeof v.controlState !== 'string' || !states.has(v.controlState) || !canonicalHash(v.populationSha256) || typeof v.cancelRequested !== 'boolean' || v.remoteStopProven !== false || v.resultAvailable !== false) return failure();
  return Object.freeze(v) as unknown as Readonly<ControlMetadata>;
}
interface Window { readonly wall: number; readonly mono: number; end: number; readonly signal: AbortSignal; proxyMonoEnd: bigint; }
const remaining = (window: Window): number => {
  const ms = Math.min(window.end - Date.now(), window.end - window.wall - (performance.now() - window.mono), Number(window.proxyMonoEnd - process.hrtime.bigint()) / 1e6);
  if (window.signal.aborted || ms <= 0) return failure();
  return Math.max(1, Math.floor(ms));
};
async function within<T>(promise: Promise<T>, window: Window): Promise<T> {
  const ms = remaining(window);
  let timer: ReturnType<typeof setTimeout> | undefined;
  let onAbort: (() => void) | undefined;
  try {
    return await Promise.race([promise,new Promise<never>((_,reject) => {
      timer = setTimeout(() => reject(new Error('Replacement control unavailable')),ms);
      onAbort = () => reject(new Error('Replacement control unavailable'));
      window.signal.addEventListener('abort',onAbort,{once:true});
      if (window.signal.aborted) onAbort();
    })]);
  } finally { if (timer) clearTimeout(timer); if (onAbort) window.signal.removeEventListener('abort',onAbort); }
}
async function identity(binding: Readonly<ProtectedBinding>, window: Window): Promise<void> {
  // The sole production adapter: no supplied snapshot, JWT decoding, role,
  // fixture cookie, service client or caller-selected identity can enter here.
  const { getServerSupabase } = await within(import('./supabase/server'),window);
  const client = await within(getServerSupabase(),window);
  const { data, error } = await within(client.auth.getUser(),window);
  if (error || !data.user?.id) return failure();
  const { getEmployeeForAuthUser } = await within(import('./auth-guard'),window);
  const employee = await within(getEmployeeForAuthUser(data.user.id),window);
  // Supabase exposes this actual configured property at runtime but marks it
  // protected in its TypeScript class; validate the value without a type cast.
  const actualProjectUrl: unknown = Reflect.get(client, 'supabaseUrl');
  if (typeof actualProjectUrl !== 'string') return failure();
  if (!employee || !matchesIdentity(binding, { configuredProjectUrl: process.env.NEXT_PUBLIC_SUPABASE_URL ?? '', actualProjectUrl, verifiedUserId:data.user.id,employeeId:employee.id,disabledAt:employee.disabledAt })) return failure();
  remaining(window);
}
function current(initial: InstalledBinding<ProtectedBinding>, window: Window): void {
  const again = initial.profile.purpose==='employee-conversation-web-binding-v1'?readInstalledConversationBinding():initial.profile.purpose==='replacement-upload-web-binding-v1'?readInstalledUploadBinding():initial.profile.purpose==='replacement-original-web-binding-v1'?readInstalledViewerBinding():readInstalledBinding();
  if (canonicalJson(again.profile) !== canonicalJson(initial.profile)) return failure();
  window.end = Math.min(window.end,instant(again.profile.expires_at),instant(again.profile.original_horizon));
  remaining(window);
}
function origin(request: Request, binding: Readonly<ProtectedBinding>): void {
  if (request.method !== 'POST' || request.headers.get('origin') !== binding.web_origin || new URL(request.url).origin !== binding.web_origin || request.headers.get('content-type') !== 'application/json' || request.headers.has('content-encoding')) return failure();
}
async function readBody(request: Request, window: Window,limit=65536): Promise<Buffer> {
  const declared = request.headers.get('content-length');
  if (declared !== null && (!/^[1-9][0-9]{0,6}$/.test(declared) || Number(declared) > limit)) return failure();
  if (!request.body) return failure();
  const reader = request.body.getReader(); const chunks: Uint8Array[] = []; let length = 0;
  try {
    for (;;) {
      const next = await within(reader.read(),window); if (next.done) break;
      length += next.value.length; if (length > limit) return failure(); chunks.push(next.value);
    }
    if (!length || (declared !== null && Number(declared) !== length)) return failure();
    return Buffer.concat(chunks,length);
  } finally { void reader.cancel().catch(() => undefined); reader.releaseLock(); }
}
/** Exact Python requester wire, including the unchanged caller narrowing value. */
export function validateControlRequest(bytes: Uint8Array): Readonly<Record<string, unknown>> {
  const v = parseClosedJson(bytes,65536);
  if (!v || typeof v !== 'object' || Array.isArray(v)) return failure();
  const p = v as Record<string,unknown>;
  const common = ['schema_version','operation','caller_deadline'];
  if (p.schema_version !== 1 || typeof p.operation !== 'string') return failure();
  instant(p.caller_deadline);
  if (p.operation === 'reserve') {
    if (!exact(p,[...common,'source_selectors','population_sha256','idempotency_key']) || !canonicalHash(p.population_sha256) || !canonicalUuid(p.idempotency_key) || !Array.isArray(p.source_selectors) || p.source_selectors.length < 1 || p.source_selectors.length > 100) return failure();
    const seen = new Set<string>();
    for (const s of p.source_selectors) {
      if (!exact(s,['source_id','revision']) || !canonicalUuid(s.source_id) || !integer(s.revision) || seen.has(s.source_id)) return failure();
      seen.add(s.source_id);
    }
  } else if (p.operation === 'status') {
    if (!exact(p,[...common,'run_id']) || !canonicalUuid(p.run_id)) return failure();
  } else if (p.operation === 'cancel') {
    if (!exact(p,[...common,'run_id','expected_revision','reason','idempotency_key']) || !canonicalUuid(p.run_id) || !integer(p.expected_revision) || !canonicalUuid(p.idempotency_key) || typeof p.reason !== 'string' || [...p.reason].length < 1 || [...p.reason].length > 1600) return failure();
  } else return failure();
  if (canonicalJson(p) !== Buffer.from(bytes).toString('utf8')) return failure();
  return Object.freeze(p);
}

async function transport(installed: InstalledBinding<ProtectedBinding>, body: Buffer, window: Window,pin?:Readonly<ViewerSourcePin>): Promise<Readonly<ControlMetadata>|OriginalPacket|UploadResponse|ConversationPacket> {
  const p = installed.profile; const url = new URL(p.backend_origin);
  let socket: tls.TLSSocket | undefined; let request: ReturnType<typeof https.request> | undefined;
  const abort = () => { request?.destroy(); socket?.destroy(); };
  window.signal.addEventListener('abort',abort,{once:true});
  try {
    socket = tls.connect({host:p.server_dns,port:url.port ? Number(url.port) : 443,servername:p.server_dns,ca:installed.ca,cert:installed.cert,key:installed.key,rejectUnauthorized:true,minVersion:'TLSv1.2',ALPNProtocols:['http/1.1'],checkServerIdentity:(host,cert) => tls.checkServerIdentity(host,cert) ?? (sha256(cert.raw) === p.server_certificate_der_sha256 ? undefined : new Error('Replacement control unavailable'))});
    socket.on('error',() => undefined);
    socket.setTimeout(remaining(window),() => socket?.destroy(new Error('Replacement control unavailable')));
    await within(new Promise<void>((resolve,reject) => { socket!.once('secureConnect',() => {
      try {
        if (!socket!.authorized || tls.checkServerIdentity(p.server_dns,socket!.getPeerCertificate()) || sha256(socket!.getPeerCertificate().raw) !== p.server_certificate_der_sha256 || (socket!.alpnProtocol && socket!.alpnProtocol !== 'http/1.1')) return reject(new Error('Replacement control unavailable'));
        resolve();
      } catch { reject(new Error('Replacement control unavailable')); }
    }); socket!.once('error',reject); socket!.once('close',() => reject(new Error('Replacement control unavailable'))); }),window);
    // No HTTP bytes exist until chain, hostname and actual leaf DER pass.
    current(installed,window);
    await identity(p,window);
    current(installed,window);
    const connected = socket;
    // Node HTTP closes Connection:close responses with destroySoon after the
    // declared body. Keep this verified TLS socket's read side owned until its
    // actual peer end; the unchanged absolute timer/abort still destroys it.
    connected.destroySoon = () => connected.end();
    // Keep observing the same verified socket after Node detaches its HTTP
    // parser. Count bytes only; HTTPS remains the sole semantic HTTP parser.
    const headerLimit=16384,bodyLimit=pin?MAX_ORIGINAL_BYTES:p.purpose==='employee-conversation-web-binding-v1'?4194304:16384;
    let wireSize=0,headerPrefix=Buffer.alloc(0),headerLength:number|undefined,expectedWireSize:number|undefined,wireFailed=false;
    let rejectWire:(()=>void)|undefined;
    const wireRefuse=()=>{wireFailed=true;rejectWire?.();abort();};
    const observeWire=(chunk:Buffer)=>{
      if(wireFailed)return;wireSize+=chunk.length;
      if(wireSize>headerLimit+bodyLimit){wireRefuse();return;}
      if(headerLength===undefined){
        headerPrefix=Buffer.concat([headerPrefix,chunk.subarray(0,headerLimit-headerPrefix.length)]);
        const boundary=headerPrefix.indexOf('\r\n\r\n');
        if(boundary>=0){headerLength=boundary+4;headerPrefix=Buffer.alloc(0);}
        else if(headerPrefix.length===headerLimit){wireRefuse();return;}
      }
      if(expectedWireSize!==undefined&&wireSize>expectedWireSize)wireRefuse();
    };
    connected.on('data',observeWire);
    const agent = new https.Agent({keepAlive:false,maxSockets:1});
    agent.createConnection = () => connected;
    try {
      const response = new Promise<Readonly<ControlMetadata>|OriginalPacket|UploadResponse|ConversationPacket>((resolve,reject) => {
        let metadata: Readonly<ControlMetadata>|OriginalPacket|UploadResponse|ConversationPacket|undefined; let ended = false; let peerEnded = false; let responseCount = 0;
        const refuse = () => reject(new Error('Replacement control unavailable'));
        rejectWire=refuse;
        connected.once('end',() => { peerEnded = true; });
        connected.once('close',(hadError) => { if (hadError || !peerEnded || !ended || !metadata || wireFailed || headerLength===undefined || expectedWireSize===undefined || wireSize!==expectedWireSize) refuse(); else resolve(metadata); });
        request = https.request({protocol:'https:',hostname:p.server_dns,port:url.port || 443,path:p.purpose==='employee-conversation-web-binding-v1'?p.conversation_path:p.purpose==='replacement-upload-web-binding-v1'?p.upload_path:p.purpose==='replacement-original-web-binding-v1'?p.original_path:p.control_path,method:'POST',agent,headers:{'Content-Type':'application/json','Content-Length':String(body.length),'Connection':'close'}},res => {
          responseCount++; if (responseCount !== 1 || res.statusCode !== 200 || res.headers['content-type'] !== (pin?'application/pdf':'application/json') || res.headers['content-encoding'] !== undefined || res.headers['transfer-encoding'] !== undefined || res.headers.connection !== 'close') { refuse(); abort(); return; }
          const seen = new Set<string>();
          for (let i = 0; i < res.rawHeaders.length; i += 2) { const h = res.rawHeaders[i]!.toLowerCase(); if (seen.has(h)) { refuse(); abort(); return; } seen.add(h); }
          const len = res.headers['content-length'];
          if (typeof len !== 'string' || !/^[1-9][0-9]{0,7}$/.test(len) || Number(len) > (pin?MAX_ORIGINAL_BYTES:p.purpose==='employee-conversation-web-binding-v1'?4194304:p.purpose==='replacement-upload-web-binding-v1'?16384:4096) || (pin!==undefined&&Number(len)!==pin.byte_count)) { refuse(); abort(); return; }
          if(headerLength===undefined){wireRefuse();return;}expectedWireSize=headerLength+Number(len);
          if(wireSize>expectedWireSize){wireRefuse();return;}
          let lease:string|undefined;
          if(pin){
            try{
              const value=res.headers['x-oracle-original-valid-until'];
              if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{6}Z$/.test(value)||res.headers['cache-control']!=='no-store, private'||res.headers['x-content-type-options']!=='nosniff'||res.headers['accept-ranges']!==undefined)throw new Error();
              const end=instant(value);if(end<=Date.now()||end>window.end)throw new Error();
              lease=value;window.end=Math.min(window.end,end);connected.setTimeout(remaining(window));
            }catch{refuse();abort();return;}
          }
          let size = 0; const chunks: Buffer[] = [];const original=pin?Buffer.alloc(pin.byte_count):undefined;
          res.on('data',(chunk: Buffer) => {
            try { connected.setTimeout(remaining(window)); size += chunk.length; if (size > Number(len)) throw new Error(); if(original)chunk.copy(original,size-chunk.length);else chunks.push(chunk); }
            catch { refuse(); abort(); }
          });
          res.once('aborted',refuse); res.once('error',refuse);
          res.once('end',() => { try { remaining(window); if (!res.complete || size !== Number(len) || res.trailers && Object.keys(res.trailers).length) return refuse(); if(pin&&original&&lease){if(!original.subarray(0,5).equals(Buffer.from('%PDF-'))||sha256(original)!==pin.original_sha256)throw new Error();remaining(window);metadata={data:original,validUntil:lease};}else metadata = p.purpose==='employee-conversation-web-binding-v1'?parseConversationResponse(Buffer.concat(chunks,size)):p.purpose==='replacement-upload-web-binding-v1'?parseUploadResponse(Buffer.concat(chunks,size)):parseControlMetadata(Buffer.concat(chunks,size)); ended = true; } catch { refuse(); abort(); } });
        });
        request.once('error',refuse);
        request.setTimeout(remaining(window),() => { refuse(); abort(); });
        request.end(body);
      });
      return await within(response,window);
    } finally { connected.removeListener('data',observeWire);agent.destroy(); }
  } finally { window.signal.removeEventListener('abort',abort); abort(); }
}
export type ProtectedControlResult = Readonly<{available:true;metadata:Readonly<ControlMetadata>}> | Readonly<{available:false}>;
/** Sole production entry point. Captures wall+monotonic start before binding,
 * verified identity or request-body work. Client cancellation only closes this
 * connection; it never proves remote stop. No automatic replay is performed.
 */
export async function requestReplacementControl(request: Request): Promise<ProtectedControlResult> {
  const wall = Date.now(), mono = performance.now();
  const window: Window = {wall,mono,end:wall + 30000,signal:request.signal,proxyMonoEnd:process.hrtime.bigint()+30000000000n};
  try {
    const proxyWindow=readControlWindow(request.headers);
    window.end=Math.min(window.end,proxyWindow.wall_end);window.proxyMonoEnd=BigInt(proxyWindow.mono_end);
    const installed = readInstalledBinding();
    window.end = Math.min(window.end,instant(installed.profile.expires_at),instant(installed.profile.original_horizon));
    origin(request,installed.profile); remaining(window);
    await identity(installed.profile,window);
    const body = await readBody(request,window); const dto = validateControlRequest(body);
    const callerDeadline = instant(dto.caller_deadline);
    // Caller input narrows this original window; never mint, clamp or renew it.
    if (callerDeadline <= Date.now() || callerDeadline > wall + 30000 || callerDeadline > proxyWindow.wall_end || callerDeadline > instant(installed.profile.original_horizon) || callerDeadline > instant(installed.profile.expires_at)) return failure();
    window.end = Math.min(window.end,callerDeadline);
    current(installed,window); await identity(installed.profile,window); current(installed,window);
    const response = await transport(installed,body,window);
    if(!('runId' in response))return failure();const metadata=response;
    if (dto.operation === 'reserve' ? metadata.populationSha256 !== dto.population_sha256 : metadata.runId !== dto.run_id) return failure();
    current(installed,window); await identity(installed.profile,window); current(installed,window);
    // The original deadline remains private in this invocation and the exact
    // request bytes. A later explicit identical request still needs every gate.
    return Object.freeze({available:true,metadata});
  } catch { return Object.freeze({available:false}); }
}

interface OriginalPacket {readonly data:Buffer;readonly validUntil:string;}
/** Closed original-view wire: exact Python post-validation datetime rendering. */
export function validateOriginalViewRequest(bytes:Uint8Array):Readonly<Record<string,unknown>>{
  const v=parseClosedJson(bytes,4096);
  if(!exact(v,['schema_version','source_id','revision','caller_deadline'])||v.schema_version!==1||!canonicalUuid(v.source_id)||typeof v.revision!=='number'||!Number.isSafeInteger(v.revision)||v.revision<1||typeof v.caller_deadline!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.(?!000000)[0-9]{6})?Z$/.test(v.caller_deadline)||canonicalJson(v)!==Buffer.from(bytes).toString('utf8'))return failure();
  instant(v.caller_deadline);return Object.freeze(v);
}
let viewerBusy=false;
/** Original bytes only; separate installed purpose, no result/truth/writer grant. */
export async function requestReplacementOriginal(request:Request):Promise<Response>{
  const wall=Date.now(),mono=performance.now();
  const window:Window={wall,mono,end:wall+30000,signal:request.signal,proxyMonoEnd:process.hrtime.bigint()+30000000000n};
  if(viewerBusy)return unavailableControl();viewerBusy=true;let handedOff=false;
  try{
    const proxyWindow=readControlWindow(request.headers);window.end=Math.min(window.end,proxyWindow.wall_end);window.proxyMonoEnd=BigInt(proxyWindow.mono_end);
    const installed=readInstalledViewerBinding(),profile=installed.profile;
    window.end=Math.min(window.end,instant(profile.expires_at),instant(profile.original_horizon));
    origin(request,profile);if(['range','if-range','if-match','if-none-match','if-modified-since','if-unmodified-since','expect'].some(k=>request.headers.has(k)))return unavailableControl();
    remaining(window);await identity(profile,window);
    const bytes=await readBody(request,window,4096),dto=validateOriginalViewRequest(bytes),deadline=instant(dto.caller_deadline);
    if(deadline<=Date.now()||deadline>window.end)return unavailableControl();window.end=Math.min(window.end,deadline);
    const pins=profile.sources.filter(pin=>pin.source_id===dto.source_id&&pin.revision===dto.revision);if(pins.length!==1)return unavailableControl();
    current(installed,window);await identity(profile,window);current(installed,window);
    const result=await transport(installed,bytes,window,pins[0]);if(!('data' in result))return unavailableControl();
    current(installed,window);await identity(profile,window);current(installed,window);remaining(window);
    let offset=0,timer:ReturnType<typeof setTimeout>|undefined,closed=false,controller:ReadableStreamDefaultController<Uint8Array>|undefined;
    const release=()=>{if(closed)return;closed=true;if(timer)clearTimeout(timer);request.signal.removeEventListener('abort',abort);viewerBusy=false;};
    const abort=()=>{if(closed)return;controller?.error(new Error('Replacement control unavailable'));release();};
    const stream=new ReadableStream<Uint8Array>({
      start(c){controller=c;timer=setTimeout(abort,remaining(window));request.signal.addEventListener('abort',abort,{once:true});if(request.signal.aborted)abort();},
      pull(c){try{current(installed,window);remaining(window);const end=Math.min(offset+65536,result.data.length);c.enqueue(result.data.subarray(offset,end));offset=end;if(offset===result.data.length){c.close();release();}}catch{abort();}},
      cancel(){release();},
    },{highWaterMark:0});
    handedOff=true;return new Response(stream,{status:200,headers:{...privateControlHeaders,'Content-Type':'application/pdf','Content-Length':String(result.data.length),'Content-Disposition':'inline; filename="original.pdf"'}});
  }catch{return unavailableControl();}
  finally{if(!handedOff)viewerBusy=false;}
}

// Same fixed auth/TLS/file/window owners; only this installed purpose chooses
// the chunk endpoint. No transport selector is accepted from the browser.
import { UPLOAD_CHUNK_BYTES,UPLOAD_MAX_REQUEST_BYTES,type UploadResponse } from './replacement-upload-contract';
export function validateUploadRequest(bytes:Uint8Array):Readonly<Record<string,unknown>>{
 const v=parseClosedJson(bytes,UPLOAD_MAX_REQUEST_BYTES);
 if(!v||typeof v!=='object'||Array.isArray(v))return failure();const p=v as Record<string,unknown>;
 if(p.schema_version!==1||typeof p.operation!=='string'||typeof p.caller_deadline!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.(?!000000)[0-9]{6})?Z$/.test(p.caller_deadline)||canonicalJson(p)!==Buffer.from(bytes).toString('utf8'))return failure();
 instant(p.caller_deadline);
 if(p.operation==='begin'){
  if(!exact(p,['schema_version','operation','source_id','expected_head','idempotency_key','filename','original_sha256','byte_count','caller_deadline'])||!Number.isSafeInteger(p.expected_head)||(p.expected_head as number)<0||((p.source_id===null)!==(p.expected_head===0))||(p.source_id!==null&&!canonicalUuid(p.source_id))||!canonicalUuid(p.idempotency_key)||typeof p.filename!=='string'||[...p.filename].length<1||[...p.filename].length>255||/[\/\\\u0000-\u001f\u007f]/.test(p.filename)||!canonicalHash(p.original_sha256)||!Number.isSafeInteger(p.byte_count)||(p.byte_count as number)<1||(p.byte_count as number)>MAX_ORIGINAL_BYTES)return failure();
 }else{
  const fields=['schema_version','operation','reservation_id','source_id','revision','begin_sha256','caller_deadline'];
  if(!canonicalUuid(p.reservation_id)||!canonicalUuid(p.source_id)||!Number.isSafeInteger(p.revision)||(p.revision as number)<1||!canonicalHash(p.begin_sha256))return failure();
  if(p.operation==='chunk'){
   if(!exact(p,[...fields,'chunk_index','offset','chunk_sha256','data_base64'])||!Number.isSafeInteger(p.chunk_index)||(p.chunk_index as number)<0||(p.chunk_index as number)>12||p.offset!==(p.chunk_index as number)*UPLOAD_CHUNK_BYTES||!canonicalHash(p.chunk_sha256)||typeof p.data_base64!=='string'||p.data_base64.length>2796204||!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(p.data_base64))return failure();
   const data=Buffer.from(p.data_base64,'base64');if(!data.length||data.length>UPLOAD_CHUNK_BYTES||data.toString('base64')!==p.data_base64||sha256(data)!==p.chunk_sha256)return failure();
  }else if(!['status','cancel','finalize'].includes(p.operation)||!exact(p,fields))return failure();
 }
 return Object.freeze(p);
}
export function parseUploadResponse(bytes:Uint8Array):Readonly<UploadResponse>{
 const v=parseClosedJson(bytes,16384);
 if(!exact(v,['schema_version','state','reservation_id','source_id','revision','begin_sha256','received_bytes','next_chunk_index','valid_until','qualification','remote_stop_proven','observation_only','source_snapshot'])||v.schema_version!==1||typeof v.state!=='string'||!['reserved','receiving','finalizing','committed','cancelled','expired','UNKNOWN'].includes(v.state)||!canonicalUuid(v.reservation_id)||!canonicalUuid(v.source_id)||!Number.isSafeInteger(v.revision)||(v.revision as number)<1||!canonicalHash(v.begin_sha256)||!Number.isSafeInteger(v.received_bytes)||(v.received_bytes as number)<0||(v.received_bytes as number)>MAX_ORIGINAL_BYTES||!Number.isSafeInteger(v.next_chunk_index)||(v.next_chunk_index as number)<0||(v.next_chunk_index as number)>13||v.qualification!==false||v.remote_stop_proven!==false||v.observation_only!==true||canonicalJson(v)!==Buffer.from(bytes).toString('utf8'))return failure();
 instant(v.valid_until);
 if(v.next_chunk_index!==Math.ceil((v.received_bytes as number)/UPLOAD_CHUNK_BYTES)||(v.state==='reserved'&&v.received_bytes!==0)||(['receiving','committed'].includes(v.state)&&v.received_bytes===0))return failure();
 if(v.source_snapshot!==null){const s=v.source_snapshot;if(v.state!=='committed'||!exact(s,['sourceId','revision','originalSha256','byteCount','mediaType','filename','state','qualifiedSourceRef'])||s.sourceId!==v.source_id||s.revision!==v.revision||!canonicalHash(s.originalSha256)||s.byteCount!==v.received_bytes||s.mediaType!=='application/pdf'||typeof s.filename!=='string'||[...s.filename].length<1||[...s.filename].length>255||s.state!=='awaiting_original_reading'||s.qualifiedSourceRef!==null)return failure();Object.freeze(s);}
 return Object.freeze(v) as unknown as Readonly<UploadResponse>;
}
export async function requestReplacementUpload(request:Request):Promise<Response>{
 const wall=Date.now(),mono=performance.now();const window:Window={wall,mono,end:wall+30000,signal:request.signal,proxyMonoEnd:process.hrtime.bigint()+30000000000n};
 try{
  const proxyWindow=readControlWindow(request.headers);window.end=Math.min(window.end,proxyWindow.wall_end);window.proxyMonoEnd=BigInt(proxyWindow.mono_end);
  const installed=readInstalledUploadBinding(),profile=installed.profile;window.end=Math.min(window.end,instant(profile.expires_at),instant(profile.original_horizon));
  origin(request,profile);if(['range','if-range','if-match','if-none-match','if-modified-since','if-unmodified-since','expect'].some(k=>request.headers.has(k)))return unavailableControl();
  await identity(profile,window);const body=await readBody(request,window,UPLOAD_MAX_REQUEST_BYTES),dto=validateUploadRequest(body),deadline=instant(dto.caller_deadline);
  if(deadline<=Date.now()||deadline>window.end)return unavailableControl();window.end=Math.min(window.end,deadline);
  current(installed,window);await identity(profile,window);current(installed,window);
  const result=await transport(installed,body,window);if(!('observation_only' in result))return unavailableControl();
  const end=instant(result.valid_until);if(end<=Date.now()||end>window.end)return unavailableControl();window.end=Math.min(window.end,end);
  if(dto.operation!=='begin'&&(dto.reservation_id!==result.reservation_id||dto.source_id!==result.source_id||dto.revision!==result.revision||dto.begin_sha256!==result.begin_sha256))return unavailableControl();
  if(dto.operation==='begin'&&(result.begin_sha256!==sha256(body)||(dto.source_id!==null&&dto.source_id!==result.source_id)||result.revision!==(dto.expected_head as number)+1||result.received_bytes>(dto.byte_count as number)))return unavailableControl();
  if(dto.operation!=='finalize'&&result.source_snapshot!==null)return unavailableControl();
  current(installed,window);await identity(profile,window);current(installed,window);remaining(window);
  return new Response(canonicalJson(result),{status:200,headers:{...privateControlHeaders,'Content-Type':'application/json'}});
 }catch{return unavailableControl();}
}

/** Same sole verified identity/clock/socket owner, separate installed purpose. */
export async function requestEmployeeConversation(request:Request):Promise<ConversationPacket|undefined>{
 const wall=Date.now(),mono=performance.now();const window:Window={wall,mono,end:wall+30000,signal:request.signal,proxyMonoEnd:process.hrtime.bigint()+30000000000n};
 try{
  const url=new URL(request.url);if(!isConversationPath(url.pathname)||url.search)return undefined;
  const proxyWindow=readControlWindow(request.headers);window.end=Math.min(window.end,proxyWindow.wall_end);window.proxyMonoEnd=BigInt(proxyWindow.mono_end);
  const installed=readInstalledConversationBinding();window.end=Math.min(window.end,instant(installed.profile.expires_at),instant(installed.profile.original_horizon));
  origin(request,installed.profile);remaining(window);await identity(installed.profile,window);
  const body=await readBody(request,window);const q=validateConversationRequest(body);const deadline=instant(q.caller_deadline);
  if(deadline<=Date.now()||deadline>window.end||deadline>wall+30000)return undefined;window.end=Math.min(window.end,deadline);
  if(url.pathname!=='/api/consultant/interviews'&&q.thread_id!==url.pathname.split('/')[4])return undefined;
  if(url.pathname==='/api/consultant/interviews'&&q.operation!==undefined&&!['list','status'].includes(String(q.operation)))return undefined;
  current(installed,window);await identity(installed.profile,window);current(installed,window);
  const response=await transport(installed,body,window);
  if('runId'in response||'data'in response||!('schema_version'in response))return undefined;
  const result=response as ConversationPacket;
  if('principal_id'in result&&(result.principal_id!==installed.profile.principal_id||result.workspace_id!==installed.profile.workspace_id))return undefined;
  if(q.thread_id&&'thread_id'in result&&result.thread_id!==q.thread_id)return undefined;
  current(installed,window);await identity(installed.profile,window);current(installed,window);return result;
 }catch{return undefined;}
}
