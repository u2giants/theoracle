"""Native-only provider broker: immutable jobs, one key, one actual ledger.

Only the trusted broker owns the existing provider credential. Executor RPC
clients supply an opaque job identifier and matching sealed request, never a
sender, allowance, price, permission claim or pre-reserved billing ticket.
Registry issuance, current job resolution and authority are coordinator duties;
this module does not manufacture any of those proofs.
"""
from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Literal
from uuid import UUID,uuid4

import psycopg
from pydantic import AwareDatetime, Field, model_validator, field_validator

from oracle_brain.provider_policy import ProcessingApproval, ProcessingRequest, authorize
from .contracts import StrictRecord, SourceRef, canonical_bytes, digest
from .key_coverage import VerifiedKeyCoverage
from .native_provider import NativeOpenRouter
from .provider_adapter import AdmittedProvider, Budget, Pricing, ConversationTextPricingV1
from .original_qualification_v1 import RawOriginalRefV1
from .raw_multimodal_pricing_v1 import RawMultimodalPricingQuoteV1


class LedgerRegistry(StrictRecord):
    key_fingerprint: str = Field(pattern=r'^[0-9a-f]{64}$')
    host: str = Field(min_length=1)
    port: int = Field(strict=True, gt=0, le=65535)
    database: str = Field(min_length=1)
    role: str = Field(min_length=1)
    cluster_identifier: str = Field(pattern=r'^[0-9]+$')
    namespace_hash: str = Field(pattern=r'^[0-9a-f]{64}$')
    transport: Literal['verify-full-tls', 'owned-synthetic-loopback']
    transport_receipt_hash: str = Field(pattern=r'^[0-9a-f]{64}$')
    dedicated_single_key: Literal[True]
    issuer_actor: UUID
    reviewer_actor: UUID
    expires_at: AwareDatetime


class NativeDispatchJob(StrictRecord):
    dispatch_id: UUID
    workspace_id: UUID
    artifact_id: UUID
    batch_id: UUID
    purpose: Literal['source-census', 'source-extraction', 'operating-audit', 'independent-source-semantic-acceptance','employee-conversation']
    attempt: Literal[1, 2]
    request: dict
    request_hash: str = Field(pattern=r'^[0-9a-f]{64}$')
    permission_hash: str = Field(pattern=r'^[0-9a-f]{64}$')
    processing_request: ProcessingRequest
    approvals: tuple[ProcessingApproval, ...]
    pricing: Pricing
    register_hash: str = Field(pattern=r'^[0-9a-f]{64}$')
    input_tokens_upper_bound: int = Field(strict=True, gt=0)


class EmployeeConversationDispatchJobV1(NativeDispatchJob):
    """Externally appointed immutable conversation operation, never evidence."""
    schema_version:Literal[1]=1
    job_schema:Literal['employee-conversation-dispatch-v1']='employee-conversation-dispatch-v1'
    pricing:ConversationTextPricingV1
    purpose:Literal['employee-conversation']='employee-conversation'
    attempt:Literal[1]=1
    thread_id:UUID
    thread_revision:int=Field(strict=True,ge=1)
    employee_event_id:UUID
    original_sha256:str=Field(pattern=r'^[0-9a-f]{64}$')
    billing_bounds_sha256:str=Field(pattern=r'^[0-9a-f]{64}$')
    pending_question_id:UUID|None
    qualified_population:tuple['SourceRef',...]=Field(max_length=4096)
    qualified_population_sha256:str=Field(pattern=r'^[0-9a-f]{64}$')
    @field_validator('attempt',mode='before')
    @classmethod
    def exact_one_attempt(cls,value):
        if type(value) is not int or value!=1:raise ValueError('exact first conversation attempt required')
        return value
    @model_validator(mode='after')
    def exact_conversation_operation(self):
        if (self.dispatch_id!=self.artifact_id or self.processing_request.purpose!=self.purpose
            or self.request_hash!=digest(self.request)
            or self.qualified_population_sha256!=digest({'source_refs':[x.model_dump(mode='json') for x in self.qualified_population]})
            or len({(x.source_id,x.revision) for x in self.qualified_population})!=len(self.qualified_population)):
            raise ValueError('exact one-attempt conversation operation and qualified population required')
        return self


class RawOriginalDispatchJobV1(NativeDispatchJob):
    """Fixed paid PDF phases before a qualified SourceRef can exist."""
    schema_version:Literal[1]=1
    job_schema:Literal['raw-original-dispatch-v1']='raw-original-dispatch-v1'
    purpose:Literal['source-original-reading','source-original-review']
    raw_ref: 'RawOriginalRefV1'
    pricing:RawMultimodalPricingQuoteV1
    population_id:UUID
    operation_registry_hash:str=Field(pattern=r'^[0-9a-f]{64}$')
    view_manifest_hash:str=Field(pattern=r'^[0-9a-f]{64}$')
    locator_map_hash:str=Field(pattern=r'^[0-9a-f]{64}$')
    reading_commit_hash:str|None=Field(default=None,pattern=r'^[0-9a-f]{64}$')

    @field_validator('schema_version',mode='before')
    @classmethod
    def exact_version_integer(cls,value):
        if type(value) is not int or value!=1:
            raise ValueError('raw native job version must be integer one')
        return value

    @model_validator(mode='after')
    def exact_original_phase(self):
        if (self.raw_ref.media_type!='application/pdf' or self.raw_ref.workspace_id!=self.workspace_id
                or self.processing_request.purpose!=self.purpose
                or (self.purpose=='source-original-review')!=(self.reading_commit_hash is not None)
                or self.pricing.dispatch_id!=self.dispatch_id or self.pricing.request_hash!=self.request_hash
                or self.pricing.population_id!=self.population_id
                or self.pricing.view_manifest_hash!=self.view_manifest_hash
                or self.pricing.account!=self.processing_request.account
                or self.pricing.admitted_register_hash!=self.register_hash
                or self.pricing.model!=self.request.get('model')
                or self.pricing.max_output_tokens!=self.request.get('max_tokens')
                or self.input_tokens_upper_bound!=self.pricing.text_input_tokens_upper_bound+self.pricing.vision_input_tokens_upper_bound):
            raise ValueError('exact raw PDF phase, workspace and actual prior reading required')
        return self


class _AuthorizedNative(NativeOpenRouter):
    """Keep the exact native send/allowance methods; gate immediately at POST."""
    def __init__(self,*args,before_private_dispatch,**kwargs):
        super().__init__(*args,**kwargs)
        self._before_private_dispatch=before_private_dispatch

    def _request(self,path,body=None):
        if path in {'/chat/completions','/embeddings'}:
            self._before_private_dispatch()
            self._coverage(datetime.now(timezone.utc))
        response=super()._request(path,body)
        if path in {'/models','/embeddings/models'}:
            self._models_snapshot=response
        return response


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON field')
        result[key] = value
    return result


def _deny_constant(_value):
    raise ValueError('nonfinite JSON value')


def ledger_namespace_hash(connection) -> str:
    """Read-only structural fingerprint, excluding row contents and secrets."""
    rows = connection.execute("""SELECT c.relname,a.attname,format_type(a.atttypid,a.atttypmod),a.attnotnull
        FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
        JOIN pg_attribute a ON a.attrelid=c.oid
        WHERE n.nspname='oracle2' AND c.relname IN
          ('operating_dispatch_reservations','operating_dispatch_receipts','operating_dispatch_diagnoses')
          AND a.attnum>0 AND NOT a.attisdropped ORDER BY c.relname,a.attnum""").fetchall()
    constraints = connection.execute("""SELECT c.relname,pg_get_constraintdef(k.oid)
        FROM pg_constraint k JOIN pg_class c ON c.oid=k.conrelid
        JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='oracle2'
          AND c.relname IN ('operating_dispatch_reservations','operating_dispatch_receipts','operating_dispatch_diagnoses')
        ORDER BY c.relname,pg_get_constraintdef(k.oid)""").fetchall()
    triggers = connection.execute("""SELECT c.relname,pg_get_triggerdef(t.oid),pg_get_functiondef(t.tgfoid)
        FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid
        JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='oracle2' AND NOT t.tgisinternal
          AND c.relname IN ('operating_dispatch_reservations','operating_dispatch_receipts','operating_dispatch_diagnoses')
        ORDER BY c.relname,pg_get_triggerdef(t.oid)""").fetchall()
    if {row[0] for row in rows} != {'operating_dispatch_reservations','operating_dispatch_receipts','operating_dispatch_diagnoses'}:
        raise PermissionError('complete current billing namespace required')
    return digest({'columns':rows,'constraints':constraints,'triggers':triggers})


def verify_ledger(url: str, registry: LedgerRegistry, *, trusted_registry_hash: str,
                  key_fingerprint: str, now: datetime) -> str:
    """External registry asserts exclusivity; actual SQL proves target identity.

    No role grant, schema write, or self-issuance occurs during this preflight.
    Missing least-privilege metadata access denies, rather than being bypassed.
    """
    identity = digest(registry.model_dump(mode='json'))
    if (identity != trusted_registry_hash or registry.key_fingerprint != key_fingerprint
            or registry.issuer_actor == registry.reviewer_actor or registry.dedicated_single_key is not True
            or now.tzinfo is None or registry.expires_at <= now):
        raise PermissionError('independent current single-key ledger registry required')
    parts = psycopg.conninfo.conninfo_to_dict(url)
    if (parts.get('host') != registry.host or int(parts.get('port','5432')) != registry.port
            or parts.get('dbname') != registry.database or parts.get('user') != registry.role):
        raise PermissionError('actual ledger connection target differs from registry')
    if registry.transport == 'owned-synthetic-loopback':
        if registry.host not in {'127.0.0.1','localhost'} or not registry.database.startswith('oracle_operating_model_test_'):
            raise PermissionError('synthetic ledger must be owned loopback test namespace')
    elif parts.get('sslmode') != 'verify-full':
        raise PermissionError('production ledger requires verified TLS hostname')
    with psycopg.connect(url, connect_timeout=5) as connection:
        connection.execute('SET TRANSACTION READ ONLY')
        database, role, superuser, create_role, create_db, replication, bypass_rls = connection.execute("SELECT current_database(),current_user,rolsuper,rolcreaterole,rolcreatedb,rolreplication,rolbypassrls FROM pg_roles WHERE rolname=current_user").fetchone()
        if (database,role) != (registry.database,registry.role) or any((superuser,create_role,create_db,replication,bypass_rls)):
            raise PermissionError('actual least-privilege ledger role required')
        memberships=connection.execute("SELECT EXISTS(SELECT 1 FROM pg_roles WHERE rolname<>current_user AND pg_has_role(current_user,oid,'MEMBER'))").fetchone()[0]
        if memberships:
            raise PermissionError('billing role cannot inherit unbounded role capabilities')
        if registry.transport == 'verify-full-tls' and not connection.pgconn.ssl_in_use:
            raise PermissionError('production ledger connection is not TLS')
        cluster = connection.execute('SELECT system_identifier::text FROM pg_catalog.pg_control_system()').fetchone()[0]
        if cluster != registry.cluster_identifier or ledger_namespace_hash(connection) != registry.namespace_hash:
            raise PermissionError('actual ledger cluster or namespace changed')
        for table in ('operating_dispatch_reservations','operating_dispatch_receipts','operating_dispatch_diagnoses'):
            privileges = connection.execute("SELECT has_table_privilege(current_user,%s,'SELECT'),has_table_privilege(current_user,%s,'INSERT'),has_table_privilege(current_user,%s,'UPDATE'),has_table_privilege(current_user,%s,'DELETE')",('oracle2.'+table,)*4).fetchone()
            if privileges != (True,True,False,False):
                raise PermissionError('append-only least billing privileges required')
        broad_access=connection.execute("""SELECT EXISTS(SELECT 1 FROM pg_class c
            JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='oracle2' AND c.relkind IN ('r','p','v','m')
              AND c.relname NOT IN ('operating_dispatch_reservations','operating_dispatch_receipts','operating_dispatch_diagnoses')
              AND (has_table_privilege(current_user,c.oid,'SELECT') OR has_table_privilege(current_user,c.oid,'INSERT')
                   OR has_table_privilege(current_user,c.oid,'UPDATE') OR has_table_privilege(current_user,c.oid,'DELETE')))""").fetchone()[0]
        if broad_access:
            raise PermissionError('billing role cannot have broad original-ledger access')
    return identity


class NativeBrokerEgress:
    """Trusted mTLS ingress adapter; reserve and fixed send occur in one broker."""
    def __init__(self, *, api_key: str, ledger_url: str, registry: LedgerRegistry,
                 trusted_registry_hash: str, coverage_receipt: Callable[[], VerifiedKeyCoverage],
                 trusted_coverage_hash: str, resolve_job: Callable[[UUID], NativeDispatchJob],
                 authorize_current_job: Callable[[NativeDispatchJob], bool],
                 validate_response: Callable[[NativeDispatchJob, object], None], private_receipts: Path,
                 admitted_allocation=None):
        from .provider_adapter import AdmittedAllocationLimitV2
        if admitted_allocation is not None and type(admitted_allocation) is not AdmittedAllocationLimitV2:
            raise PermissionError('exact admitted shared allocation required')
        self._allocation=admitted_allocation
        self._key = api_key
        self._key_fingerprint = hashlib.sha256(api_key.encode()).hexdigest()
        self._url,self._registry,self._registry_hash = ledger_url,registry,trusted_registry_hash
        self._coverage,self._coverage_hash = coverage_receipt,trusted_coverage_hash
        self._resolve,self._authorize = resolve_job,authorize_current_job
        if not callable(validate_response):
            raise PermissionError('trusted response validator required before provider reads')
        self._validate_response = validate_response
        self._receipts = Path(private_receipts)
        if (not api_key or not self._receipts.is_dir() or self._receipts.is_symlink()
                or self._receipts.stat().st_mode & 0o077):
            raise PermissionError('existing key and protected private receipt directory required')

    def _capture_wire(self, job: NativeDispatchJob, raw: bytes, reservation_id, *, complete: bool):
        if (not isinstance(reservation_id,UUID) or type(raw) is not bytes or len(raw)>16*1024*1024
                or type(complete) is not bool):
            raise PermissionError('bounded raw wire and existing reservation required')
        wire=self._receipts/(str(job.dispatch_id)+'.wire')
        metadata=self._receipts/(str(job.dispatch_id)+'.wire.json')
        binding={'dispatch_id':str(job.dispatch_id),'reservation_id':str(reservation_id),
                 'request_hash':job.request_hash,'permission_hash':job.permission_hash,
                 'job_hash':digest(job.model_dump(mode='json')),'key_fingerprint':self._key_fingerprint,
                 'ledger_identity_hash':self._registry_hash,'raw_sha256':hashlib.sha256(raw).hexdigest(),
                 'captured_bytes':len(raw),'complete':complete,'truncated':not complete}
        for path,data in ((wire,raw),(metadata,canonical_bytes(binding))):
            descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
            with os.fdopen(descriptor,'wb') as stream:
                stream.write(data);stream.flush();os.fsync(stream.fileno())
        directory=os.open(self._receipts,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(directory)
        finally:os.close(directory)
        if wire.read_bytes()!=raw or json.loads(metadata.read_bytes())!=binding:
            raise PermissionError('durable exact wire readback failed')

    def _record(self, job: NativeDispatchJob, raw: str | None, reservation_id, *, failed: bool):
        dispatch_id=job.dispatch_id
        record = {'dispatch_id':str(dispatch_id),'reservation_id':str(reservation_id),
                  'failed':failed,'raw_response':raw,
                  'request_hash':job.request_hash,'permission_hash':job.permission_hash,
                  'job_hash':digest(job.model_dump(mode='json')),'register_hash':job.register_hash,
                  'pricing_hash':digest(job.pricing.model_dump(mode='json')),
                  'key_fingerprint':self._key_fingerprint,'ledger_identity_hash':self._registry_hash,
                  'raw_response_hash':None if raw is None else hashlib.sha256(raw.encode()).hexdigest()}
        wire_metadata=self._receipts/(str(dispatch_id)+'.wire.json')
        record['wire_custody']=json.loads(wire_metadata.read_bytes()) if wire_metadata.exists() else None
        path = self._receipts / (str(dispatch_id)+'.json')
        descriptor = os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(descriptor,'wb') as stream:
            stream.write(canonical_bytes(record));stream.flush();os.fsync(stream.fileno())

    def _retain_conversation_metadata_v1(self,job,models,endpoints,comparison):
        # Existing private native custodian, no second authority/dispatch owner.
        from .native_provider import NativeMetadataWireV1
        if type(job) is not EmployeeConversationDispatchJobV1 or type(models) is not NativeMetadataWireV1 or type(endpoints) is not NativeMetadataWireV1 or type(comparison) is not bytes:
            raise PermissionError('actual complete conversation metadata observations required')
        evidence_id=uuid4().hex
        record={'schema_version':1,'purpose':'conversation-native-metadata-observation-v1',
            'dispatch_id':str(job.dispatch_id),'job_sha256':digest(job.model_dump(mode='json')),
            'key_fingerprint':self._key_fingerprint,'ledger_registry_hash':self._registry_hash,
            'comparison_utf8':comparison.decode('utf-8'),'observations':[]}
        prefix=str(job.dispatch_id)+'.text-metadata-'+evidence_id
        for label,value in (('models',models),('endpoints',endpoints)):
            path=self._receipts/(prefix+'.'+label+'.wire')
            descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
            with os.fdopen(descriptor,'wb') as stream:
                stream.write(value.wire);stream.flush();os.fsync(stream.fileno())
            if path.read_bytes()!=value.wire:raise PermissionError('actual metadata wire custody differs')
            record['observations'].append({'path':value.path,'started_at':value.started_at.isoformat(),
                'observed_at':value.observed_at.isoformat(),'elapsed_seconds':str(value.elapsed_seconds),
                'wire_sha256':value.wire_sha256,'wire_name':path.name})
        data=canonical_bytes(record);path=self._receipts/(prefix+'.json')
        descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(descriptor,'wb') as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        directory=os.open(self._receipts,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(directory)
        finally:os.close(directory)
        if path.read_bytes()!=data:raise PermissionError('actual metadata observation custody differs')

    def dispatch(self, body: bytes, *, _conversation_control=None) -> bytes:
        if len(body)>2_000_000:
            raise PermissionError('bounded provider envelope required')
        try:
            envelope = json.loads(body,object_pairs_hook=_unique_object,parse_constant=_deny_constant)
            if not isinstance(envelope,dict) or set(envelope)!={'dispatch_id','request_hash','request'}:
                raise ValueError
            dispatch_id=UUID(envelope['dispatch_id'])
            if str(dispatch_id)!=envelope['dispatch_id']:
                raise ValueError
            job=self._resolve(dispatch_id)
            if not isinstance(job,NativeDispatchJob) or job.dispatch_id!=dispatch_id:
                raise ValueError
            # Do not retain shared mutable dictionaries returned by a resolver.
            if type(job) is RawOriginalDispatchJobV1:
                job=RawOriginalDispatchJobV1.model_validate_json(job.model_dump_json())
            elif type(job) is EmployeeConversationDispatchJobV1:
                job=EmployeeConversationDispatchJobV1.model_validate_json(job.model_dump_json())
            else:
                # Legacy base validation remains closed to new extra fields.
                job=NativeDispatchJob.model_validate_json(job.model_dump_json())
            encoded=canonical_bytes(envelope['request'])
            if (hashlib.sha256(encoded).hexdigest()!=job.request_hash
                    or envelope['request_hash']!=job.request_hash or encoded!=canonical_bytes(job.request)):
                raise ValueError
        except (ValueError,TypeError,KeyError):
            raise PermissionError('provider request differs from immutable admitted job') from None
        if job.purpose=='employee-conversation':
            from oracle_brain.hosting.conversation_native_v1 import current_conversation_dispatch_v1
            if type(job) is not EmployeeConversationDispatchJobV1:raise PermissionError('protected conversation consumer required')
            current_conversation_dispatch_v1(_conversation_control,job,self)
        elif _conversation_control is not None:raise PermissionError('conversation control cannot admit another purpose')
        if self._allocation is not None and job.batch_id!=self._allocation.batch_id:
            raise PermissionError('phase cannot choose a new allocation bucket')
        job_seal=digest(job.model_dump(mode='json'))
        def currently_authorized():
            if job.purpose=='employee-conversation':
                current_conversation_dispatch_v1(_conversation_control,job,self)
            return (digest(job.model_dump(mode='json'))==job_seal and self._authorize(job) is True
                    and digest(job.model_dump(mode='json'))==job_seal)
        if not currently_authorized():
            raise PermissionError('current job authority unavailable')
        if any((self._receipts/(str(dispatch_id)+suffix)).exists() for suffix in ('.json','.wire','.wire.json')):
            raise PermissionError('dispatch identity already has a retained response')
        # Processing permission precedes all provider pricing/key reads.
        authorize(job.processing_request,list(job.approvals))
        if (job.processing_request.account!='key-sha256:'+self._key_fingerprint
                or job.processing_request.provider!='openrouter'
                or job.processing_request.endpoint!='https://openrouter.ai/api/v1'
                or job.processing_request.purpose!=job.purpose or job.processing_request.fallback):
            raise PermissionError('exact existing key and source-only processing admission required')
        if self._registry.transport=='owned-synthetic-loopback' and not job.processing_request.data_classes<=frozenset({'synthetic'}):
            raise PermissionError('synthetic ledger cannot dispatch private company data')
        ledger_identity=verify_ledger(self._url,self._registry,trusted_registry_hash=self._registry_hash,
                                     key_fingerprint=self._key_fingerprint,now=datetime.now(timezone.utc))
        request=job.request
        embedding=request.get('model')=='openai/text-embedding-3-small'
        expected={'model','input','dimensions','encoding_format','store','provider'} if embedding else {'model','messages','max_tokens','response_format','store','stream','provider'}
        payload=request.get('input') if embedding else request.get('messages')
        output_bound=1 if embedding else request.get('max_tokens')
        policy={'only':['openai'],'allow_fallbacks':False,'require_parameters':True,'data_collection':'deny'}
        if (set(request)!=expected or request['provider']!=policy or request['store'] is not False
                or not isinstance(payload,list) or not payload
                or job.input_tokens_upper_bound<len(encoded)+1024*len(payload)):
            raise PermissionError('exact bounded native provider request required')
        if embedding:
            if (type(request['dimensions']) is not int or request['dimensions']!=256
                    or request['encoding_format']!='float'
                    or any(not isinstance(text,str) or not text for text in payload)):
                raise PermissionError('fixed bounded embedding input required')
        elif (request['stream'] is not False or request['response_format']!={'type':'json_object'}
                or request['model'] not in {'openai/gpt-6.1-sol','openai/gpt-6-astra'}
                or type(output_bound) is not int or not 1<=output_bound<=8192):
            raise PermissionError('exact bounded native chat request required')
        def before_private_dispatch():
            if not currently_authorized():
                raise PermissionError('current job authority changed before private POST')
            authorize(job.processing_request,list(job.approvals))
            if job.purpose=='employee-conversation':
                current_text_metadata_v1(_conversation_control,job,self,native)
        def capture_paid_wire(raw,*,complete):
            rid=getattr(provider,'last_reservation_id',None)
            self._capture_wire(job,raw,rid,complete=complete)
        native=_AuthorizedNative(self._key,coverage_receipt=self._coverage,paid_wire_receiver=capture_paid_wire,
                               before_private_dispatch=before_private_dispatch,
                               trusted_coverage_hash=self._coverage_hash,ledger_identity_hash=ledger_identity)
        native._coverage(datetime.now(timezone.utc))
        if job.purpose=='employee-conversation':
            from oracle_brain.hosting.conversation_native_v1 import current_text_metadata_v1
            current_text_metadata_v1(_conversation_control,job,self,native)
        else:
            current=native.pricing(model=request['model'],max_output_tokens=output_bound,register_hash=job.register_hash)
            model=[item for item in native._models_snapshot.get('data',[]) if item.get('id')==request['model']]
            lengths=([model[0].get('context_length')] if embedding else [model[0].get('context_length'),model[0].get('top_provider',{}).get('context_length')]) if len(model)==1 else []
            if (len(lengths)!=(1 if embedding else 2) or any(type(value) is not int or value<=0 for value in lengths)
                    or job.input_tokens_upper_bound+(0 if embedding else output_bound)>min(lengths)):
                raise PermissionError('current complete model context cannot cover admitted input/output bounds')
            if (job.pricing.expires_at<=datetime.now(timezone.utc)
                    or current.model_dump(exclude={'expires_at'})!=job.pricing.model_dump(exclude={'expires_at'})):
                raise PermissionError('current actual pricing differs from admitted job')
        provider=AdmittedProvider(request=job.processing_request,approvals=list(job.approvals),pricing=job.pricing,
            budget=Budget(self._url,ledger_identity_hash=ledger_identity,admitted_allocation=self._allocation),sender=native.embed if embedding else native.send,operation='embedding' if embedding else 'chat',
            remaining_daily_allowance=native.allowance,admitted_register_hash=job.register_hash)
        # Recheck immediately before reservation/send, after all preflight work.
        if not currently_authorized():
            raise PermissionError('job authority changed during preflight')
        validation_failed = False
        def validate_paid_response(content):
            nonlocal validation_failed
            try:
                if not currently_authorized():
                    raise PermissionError('current validation authority unavailable') if job.purpose=='employee-conversation' else ValueError('current validation authority unavailable')
                if job.purpose=='employee-conversation':
                    from oracle_brain.hosting.conversation_native_v1 import validate_conversation_wire_v1
                    validate_conversation_wire_v1(native.last_response_text,job)
                    current_text_metadata_v1(_conversation_control,job,self,native)
                if embedding:
                    validate_embedding_response(content,count=len(payload))
                self._validate_response(job, content)
                if not currently_authorized():
                    raise PermissionError('immutable job changed during validation') if job.purpose=='employee-conversation' else ValueError('immutable job changed during validation')
            except Exception as error:
                if job.purpose=='employee-conversation' and not isinstance(error,(ValueError,TypeError,KeyError)):
                    raise
                validation_failed = True
                raise ValueError('trusted output validation rejected response') from None
        try:
            provider.extract(workspace_id=job.workspace_id,artifact_id=job.artifact_id,batch_id=job.batch_id,
                purpose=job.purpose,attempt=job.attempt,input_tokens_upper_bound=job.input_tokens_upper_bound,
                messages=payload,response_validator=validate_paid_response)
        except Exception:
            if hasattr(provider,'last_reservation_id'):
                self._record(job,getattr(native,'last_response_text',None),provider.last_reservation_id,failed=True)
            raise
        raw=getattr(native,'last_response_text',None)
        self._record(job,raw,provider.last_reservation_id,failed=validation_failed)
        authorize(job.processing_request,list(job.approvals))
        if not currently_authorized() or not isinstance(raw,str):
            raise PermissionError('current access to paid response unavailable')
        if validation_failed:
            raise ValueError('trusted output validation rejected response; diagnosis required')
        return raw.encode()


def validate_embedding_response(response, *, count):
    """Exact native vector identity and complete finite 256-dimension coverage."""
    from decimal import Decimal
    if (not isinstance(response,dict) or response.get('model')!='openai/text-embedding-3-small'
            or response.get('object')!='list' or not isinstance(response.get('data'),list)
            or len(response['data'])!=count):
        raise ValueError('embedding response identity/count mismatch')
    seen=set()
    for row in response['data']:
        if (not isinstance(row,dict) or set(row)!={'object','index','embedding'} or row['object']!='embedding'
                or type(row['index']) is not int or not 0<=row['index']<count or row['index'] in seen
                or not isinstance(row['embedding'],list) or len(row['embedding'])!=256):
            raise ValueError('embedding vector schema/dimension/index mismatch')
        seen.add(row['index'])
        for value in row['embedding']:
            if isinstance(value,bool) or not isinstance(value,(int,float,Decimal)) or not Decimal(str(value)).is_finite():
                raise ValueError('embedding vector contains nonfinite/non-numeric values')


class _ObservedAssemblyBrokerBase(NativeBrokerEgress):
    """Explicit versioned assembly path; legacy broker/extraction stays unchanged.

    Protected startup supplies the independently pinned context/custodian and
    existing SQL-backed current authority callback. This class neither issues
    those authorities nor installs a provider/runtime entry point.
    """
    def __init__(self, *, assembly_context, expected_assembly_context_hash,
                 assembly_observer, **kwargs):
        self._validate_context_types(assembly_context,assembly_observer)
        if digest(assembly_context.model_dump(mode='json'))!=expected_assembly_context_hash:
            raise PermissionError('externally pinned assembly context and actual observer required')
        self._assembly_context=assembly_context
        self._assembly_context_hash=expected_assembly_context_hash
        self._assembly_observer=assembly_observer
        actual_authorize=kwargs['authorize_current_job']
        if not callable(actual_authorize):
            raise PermissionError('actual current assembly authority required')
        def authorize_assembly(job):
            context=self._assembly_context
            clock=datetime.now(timezone.utc)
            if (digest(context.model_dump(mode='json'))!=self._assembly_context_hash
                    or context.expires_at<=clock
                    or digest(job.model_dump(mode='json'))!=digest(context.job.model_dump(mode='json'))):
                return False
            self._assembly_observer.validate_job(job,key_fingerprint=self._key_fingerprint,
                ledger_identity_hash=self._registry_hash,now=clock)
            # Actual provider dispatch must recheck current parent and every
            # source grant here; a queued metadata intent is never that proof.
            return actual_authorize(job) is True
        kwargs['authorize_current_job']=authorize_assembly
        actual_validate=kwargs['validate_response']
        if not callable(actual_validate):
            raise PermissionError('actual trusted assembly validator required')
        def validate_assembly(job,content):
            self._assembly_context.validate_candidate(content,now=datetime.now(timezone.utc))
            result=actual_validate(job,content)
            if result is not None:
                raise PermissionError('assembly response validation refused')
        kwargs['validate_response']=validate_assembly
        super().__init__(**kwargs)
        self._assembly_observer.validate_job(assembly_context.job,key_fingerprint=self._key_fingerprint,
            ledger_identity_hash=self._registry_hash,now=datetime.now(timezone.utc))

    def _capture_wire(self,job,raw,reservation_id,*,complete):
        observed=None;failure=None
        if complete:
            try:
                observed=self._assembly_observer.observe(job,raw,reservation_id,
                    key_fingerprint=self._key_fingerprint,ledger_identity_hash=self._registry_hash)
            except Exception as exc:
                failure=exc
        # Even if the new qualification expired during the paid request, retain
        # complete original wire under the existing custodian before refusing.
        super()._capture_wire(job,raw,reservation_id,complete=complete)
        if failure is not None:
            raise PermissionError('observed assembly qualification unavailable; wire retained') from None
        if observed is not None:
            self._assembly_observer.retain(self._receipts,observed)


class ObservedAssemblyBrokerEgress(_ObservedAssemblyBrokerBase):
    """Legacy assembly context/protocol only; new phases require explicit V2."""
    @staticmethod
    def _validate_context_types(context,observer):
        from .assembly_context import AssemblyJobContext
        from .captured_assembly import ObservedAssemblyCustodian
        if type(context) is not AssemblyJobContext or type(observer) is not ObservedAssemblyCustodian:
            raise PermissionError('exact legacy assembly context and custodian required')
