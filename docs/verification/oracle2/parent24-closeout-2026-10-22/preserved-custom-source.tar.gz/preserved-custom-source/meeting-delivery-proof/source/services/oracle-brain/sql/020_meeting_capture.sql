-- Dedicated Oracle operational capture only. No accepted truth/admission issuer.
-- External installation must independently appoint exact immutable admission IDs.
DO $owner$ BEGIN
 IF (SELECT nspowner FROM pg_namespace WHERE nspname='oracle2') IS DISTINCT FROM
    (SELECT oid FROM pg_roles WHERE rolname=CURRENT_USER)
 OR (SELECT proowner FROM pg_proc WHERE oid=to_regprocedure('oracle2._replacement_request_context()')) IS DISTINCT FROM
    (SELECT oid FROM pg_roles WHERE rolname=CURRENT_USER) THEN
  RAISE EXCEPTION 'dedicated reviewed Oracle owner required';
 END IF;
END $owner$;
CREATE TABLE oracle2.meeting_capture_admissions_v1 (
 admission_id uuid PRIMARY KEY,admission_sha256 text NOT NULL CHECK(admission_sha256~'^[a-f0-9]{64}$'),
 workspace_id uuid NOT NULL,meeting_id uuid NOT NULL,principal_id uuid NOT NULL,role_name name NOT NULL,
 leaf_appointment_id uuid NOT NULL REFERENCES oracle2.appointments(appointment_id),
 provider text NOT NULL CHECK(provider IN('recall','graph')),provider_account text NOT NULL CHECK(length(btrim(provider_account)) BETWEEN 1 AND 256 AND provider_account=btrim(provider_account)),
 tenant_id text NOT NULL CHECK(length(btrim(tenant_id)) BETWEEN 1 AND 256 AND tenant_id=btrim(tenant_id)),
 provider_meeting_id text NOT NULL CHECK(length(btrim(provider_meeting_id)) BETWEEN 1 AND 2048),
 supervisor_admission_id uuid,supervision_scope_sha256 text CHECK(supervision_scope_sha256~'^[a-f0-9]{64}$'),stop_mapping_sha256 text CHECK(stop_mapping_sha256~'^[a-f0-9]{64}$'),
 stop_valid_from timestamptz,stop_until timestamptz,scheduler_poll_seconds integer,stop_request_seconds integer,safety_allowance_seconds integer,stop_margin_seconds integer,
 final_mapping_id uuid,final_mapping_sha256 text CHECK(final_mapping_sha256~'^[a-f0-9]{64}$'),
 participant_epoch_id uuid,participant_epoch_sha256 text CHECK(participant_epoch_sha256~'^[a-f0-9]{64}$'),
 bot_id text,final_artifact_sha256 text CHECK(final_artifact_sha256~'^[a-f0-9]{64}$'),verifier_secret_sha256 text CHECK(verifier_secret_sha256~'^[a-f0-9]{64}$'),
 consent_packet_sha256 text NOT NULL CHECK(consent_packet_sha256~'^[a-f0-9]{64}$'),
 runtime_hash text NOT NULL CHECK(runtime_hash~'^[a-f0-9]{64}$'),registry_hash text NOT NULL CHECK(registry_hash~'^[a-f0-9]{64}$'),
 actions text[] NOT NULL CHECK(cardinality(actions) BETWEEN 1 AND 16 AND actions<@ARRAY['invite','create_intent','create_observed','create_unknown','ingress','final_artifact','process','normalized','review','cancel','status','outbox','supervised','supervise','stop_intent','stop_observed','stop_unknown','stop_reconciled','participant_turn']),
 issuer_actor uuid NOT NULL,reviewer_actor uuid NOT NULL CHECK(issuer_actor<>reviewer_actor),
 capture_until timestamptz NOT NULL,valid_from timestamptz NOT NULL,original_horizon timestamptz NOT NULL,expires_at timestamptz NOT NULL,
 CHECK(isfinite(valid_from) AND isfinite(expires_at) AND isfinite(original_horizon) AND valid_from<expires_at AND expires_at<=original_horizon),
 CHECK(isfinite(capture_until) AND valid_from<capture_until AND capture_until<=original_horizon),
 CHECK(principal_id<>issuer_actor AND principal_id<>reviewer_actor),
 CHECK(NOT ('ingress'=ANY(actions)) OR (bot_id IS NOT NULL AND length(btrim(bot_id)) BETWEEN 1 AND 256 AND verifier_secret_sha256 IS NOT NULL)));
CREATE TABLE oracle2.meeting_capture_revocations_v1 (
 revocation_id uuid PRIMARY KEY,admission_id uuid NOT NULL REFERENCES oracle2.meeting_capture_admissions_v1(admission_id),
 revoked_at timestamptz NOT NULL CHECK(isfinite(revoked_at)),reason_sha256 text NOT NULL CHECK(reason_sha256~'^[a-f0-9]{64}$'));
CREATE TABLE oracle2.meeting_capture_heads_v1 (
 workspace_id uuid NOT NULL,meeting_id uuid NOT NULL,capture_until timestamptz NOT NULL CHECK(isfinite(capture_until)),version integer NOT NULL CHECK(version>=0),
 state text NOT NULL CHECK(state IN('invited','joining','pending_mapping','waiting_room','recording_permission_pending','recording_permission_denied','capturing','capture_ended','processing','final_artifact_pending','capture_status_unknown','review','failed','UNKNOWN','cancelled')),
 pending_ingress uuid[] NOT NULL DEFAULT '{}',processed_ingress uuid[] NOT NULL DEFAULT '{}',
 last_event_id uuid,last_normalized_event_id uuid,create_intent_id uuid,last_capture_event_id uuid,capture_open boolean NOT NULL DEFAULT false,
 stop_intent_id uuid,stop_observation_id uuid,stop_state text NOT NULL DEFAULT 'not_attempted' CHECK(stop_state IN('not_attempted','inflight','observed','UNKNOWN','terminal_observed')),
 PRIMARY KEY(workspace_id,meeting_id),CHECK(cardinality(pending_ingress)<=4096 AND cardinality(processed_ingress)<=4096));
CREATE TABLE oracle2.meeting_capture_events_v1 (
 event_id uuid PRIMARY KEY,workspace_id uuid NOT NULL,meeting_id uuid NOT NULL,version integer NOT NULL CHECK(version>0),
 admission_id uuid NOT NULL REFERENCES oracle2.meeting_capture_admissions_v1(admission_id),
 actor_id uuid NOT NULL,action text NOT NULL,payload_sha256 text NOT NULL CHECK(payload_sha256~'^[a-f0-9]{64}$'),payload jsonb NOT NULL,
 operation_id uuid NOT NULL,provider text,provider_account text,provider_event_id text,
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 UNIQUE(workspace_id,meeting_id,version),UNIQUE(workspace_id,meeting_id,operation_id),
 UNIQUE(provider,provider_account,provider_event_id),
 FOREIGN KEY(workspace_id,meeting_id) REFERENCES oracle2.meeting_capture_heads_v1(workspace_id,meeting_id));
CREATE TABLE oracle2.meeting_participant_epochs_v1 (
 epoch_id uuid PRIMARY KEY,workspace_id uuid NOT NULL,meeting_id uuid NOT NULL,epoch_revision integer NOT NULL CHECK(epoch_revision>0),
 epoch_sha256 text NOT NULL CHECK(epoch_sha256~'^[a-f0-9]{64}$'),epoch_payload jsonb NOT NULL,
 UNIQUE(workspace_id,meeting_id,epoch_revision),CHECK(jsonb_typeof(epoch_payload)='object' AND octet_length(epoch_payload::text)<=1048576),
 CHECK(epoch_payload->>'purpose'='meeting-live-participant-epoch-v1' AND epoch_payload->>'epoch_id'=epoch_id::text AND epoch_payload->>'workspace_id'=workspace_id::text AND epoch_payload->>'meeting_id'=meeting_id::text),
 CHECK(epoch_payload->>'epoch_revision'=epoch_revision::text),
 CHECK(epoch_sha256=encode(sha256(convert_to(oracle2._replacement_metadata_json(epoch_payload),'UTF8')),'hex')));
CREATE TABLE oracle2.meeting_participant_epoch_revocations_v1 (
 revocation_id uuid PRIMARY KEY,epoch_id uuid NOT NULL REFERENCES oracle2.meeting_participant_epochs_v1(epoch_id),
 revoked_at timestamptz NOT NULL CHECK(isfinite(revoked_at)),reason_sha256 text NOT NULL CHECK(reason_sha256~'^[a-f0-9]{64}$'));
ALTER TABLE oracle2.meeting_capture_admissions_v1 ADD CONSTRAINT meeting_participant_epoch_fk FOREIGN KEY(participant_epoch_id) REFERENCES oracle2.meeting_participant_epochs_v1(epoch_id);
CREATE TABLE oracle2.meeting_final_mappings_v1 (
 mapping_id uuid PRIMARY KEY,workspace_id uuid NOT NULL,meeting_id uuid NOT NULL,mapping_revision integer NOT NULL CHECK(mapping_revision>0),
 raw_sha256 text NOT NULL CHECK(raw_sha256~'^[a-f0-9]{64}$'),mapping_sha256 text NOT NULL CHECK(mapping_sha256~'^[a-f0-9]{64}$'),mapping_payload jsonb NOT NULL,
 UNIQUE(workspace_id,meeting_id,raw_sha256,mapping_revision),CHECK(jsonb_typeof(mapping_payload)='object' AND octet_length(mapping_payload::text)<=1048576),
 CHECK(mapping_payload->>'purpose'='meeting-final-workspace-mapping-v1' AND mapping_payload->>'mapping_id'=mapping_id::text AND mapping_payload->>'workspace_id'=workspace_id::text AND mapping_payload->>'meeting_id'=meeting_id::text AND mapping_payload->>'mapping_revision'=mapping_revision::text AND mapping_payload->>'raw_sha256'=raw_sha256),
 CHECK(mapping_sha256=encode(sha256(convert_to(oracle2._replacement_metadata_json(mapping_payload),'UTF8')),'hex')));
CREATE TABLE oracle2.meeting_final_mapping_revocations_v1 (
 revocation_id uuid PRIMARY KEY,mapping_id uuid NOT NULL REFERENCES oracle2.meeting_final_mappings_v1(mapping_id),
 revoked_at timestamptz NOT NULL CHECK(isfinite(revoked_at)),reason_sha256 text NOT NULL CHECK(reason_sha256~'^[a-f0-9]{64}$'));
ALTER TABLE oracle2.meeting_capture_admissions_v1 ADD CONSTRAINT meeting_final_mapping_fk FOREIGN KEY(final_mapping_id) REFERENCES oracle2.meeting_final_mappings_v1(mapping_id);
REVOKE ALL ON oracle2.meeting_final_mappings_v1,oracle2.meeting_final_mapping_revocations_v1 FROM PUBLIC,oracle2_replacement_requester;
DO $immutable$ DECLARE n text; BEGIN
 FOREACH n IN ARRAY ARRAY['meeting_capture_admissions_v1','meeting_capture_revocations_v1','meeting_capture_events_v1','meeting_participant_epochs_v1','meeting_participant_epoch_revocations_v1','meeting_final_mappings_v1','meeting_final_mapping_revocations_v1'] LOOP
  EXECUTE format('CREATE TRIGGER %I BEFORE UPDATE OR DELETE ON oracle2.%I FOR EACH ROW EXECUTE FUNCTION oracle2.deny_operating_model_mutation()','immutable_'||n,n);
 END LOOP;
END $immutable$;
REVOKE ALL ON oracle2.meeting_capture_admissions_v1,oracle2.meeting_capture_revocations_v1,oracle2.meeting_capture_heads_v1,oracle2.meeting_capture_events_v1,oracle2.meeting_participant_epochs_v1,oracle2.meeting_participant_epoch_revocations_v1 FROM PUBLIC,oracle2_replacement_requester;

CREATE FUNCTION oracle2._meeting_capture_lineage_v1(m oracle2.meeting_capture_admissions_v1)
 RETURNS timestamptz LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,oracle2 AS $f$
DECLARE p oracle2.appointments%ROWTYPE;seen uuid[]:='{}';until timestamptz:=m.expires_at;rooted boolean:=false;
BEGIN
 SELECT * INTO p FROM oracle2.appointments WHERE appointment_id=m.leaf_appointment_id FOR SHARE;
 IF p.appointment_id IS NULL OR p.workspace_id<>m.workspace_id OR p.actor_id<>m.principal_id OR p.scope<>'meeting-capture' THEN
  RAISE insufficient_privilege USING MESSAGE='exact meeting leaf denied';
 END IF;
 LOOP
  IF p.appointment_id=ANY(seen) OR cardinality(seen)>=16 OR p.workspace_id<>m.workspace_id OR p.revoked_at IS NOT NULL
  OR (p.expires_at IS NOT NULL AND (NOT isfinite(p.expires_at) OR p.expires_at<=clock_timestamp())) THEN
   RAISE insufficient_privilege USING MESSAGE='meeting lineage denied';
  END IF;
  seen:=array_append(seen,p.appointment_id);until:=least(until,coalesce(p.expires_at,until));
  IF p.parent_id IS NULL THEN rooted:=(p.scope='root');EXIT;END IF;
  SELECT parent.* INTO p FROM oracle2.appointments parent WHERE parent.appointment_id=p.parent_id
   AND parent.actor_id=p.granted_by AND parent.scope IN('meeting-capture','root') FOR SHARE;
  IF p.appointment_id IS NULL THEN RAISE insufficient_privilege USING MESSAGE='meeting lineage broken';END IF;
 END LOOP;
 IF NOT rooted OR until<=clock_timestamp() THEN RAISE insufficient_privilege USING MESSAGE='meeting root denied';END IF;
 RETURN until;
END $f$;
REVOKE ALL ON FUNCTION oracle2._meeting_capture_lineage_v1(oracle2.meeting_capture_admissions_v1) FROM PUBLIC,oracle2_replacement_requester;

CREATE FUNCTION oracle2._meeting_capture_admission_v1(selected uuid,seal text,act text,deadline timestamptz)
 RETURNS oracle2.meeting_capture_admissions_v1 LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,oracle2 AS $f$
DECLARE a oracle2.hosting_request_principal_admissions%ROWTYPE;m oracle2.meeting_capture_admissions_v1%ROWTYPE;
 p oracle2.appointments%ROWTYPE;seen uuid[]:='{}';until timestamptz;rooted boolean:=false;committed_end timestamptz;
BEGIN
 a:=oracle2._replacement_request_context();
 SELECT * INTO m FROM oracle2.meeting_capture_admissions_v1 WHERE admission_id=selected FOR SHARE;
 IF m.admission_id IS NULL OR m.admission_sha256 IS DISTINCT FROM seal OR m.workspace_id<>a.workspace_id OR m.principal_id<>a.principal_id
 OR m.role_name<>SESSION_USER OR m.runtime_hash<>a.runtime_hash OR m.registry_hash<>a.registry_hash
 OR NOT(act=ANY(m.actions)) OR NOT isfinite(deadline) OR deadline<=clock_timestamp() OR deadline>clock_timestamp()+interval '30 seconds'
 OR m.valid_from>clock_timestamp() OR m.expires_at<=clock_timestamp() OR m.original_horizon<=clock_timestamp()
 OR EXISTS(SELECT 1 FROM oracle2.meeting_capture_revocations_v1 WHERE admission_id=selected) THEN
  RAISE insufficient_privilege USING MESSAGE='current meeting admission denied';
 END IF;
 SELECT capture_until INTO committed_end FROM oracle2.meeting_capture_heads_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id FOR SHARE;
 IF committed_end IS NOT NULL AND committed_end IS DISTINCT FROM m.capture_until THEN RAISE insufficient_privilege USING MESSAGE='capture end cannot change';END IF;
 until:=least(a.expires_at,m.expires_at,m.original_horizon,deadline);
 IF act IN('ingress','create_intent','participant_turn') THEN until:=least(until,m.capture_until);END IF;
 IF act IN('stop_intent','stop_observed','stop_unknown','stop_reconciled') THEN
  IF m.stop_valid_from IS NULL OR m.stop_until IS NULL OR m.stop_valid_from>clock_timestamp() OR m.stop_until<=clock_timestamp() OR m.stop_until>m.original_horizon THEN RAISE insufficient_privilege USING MESSAGE='preinstalled STOP-only window denied';END IF;
  until:=least(until,m.stop_until);
 END IF;
 m.expires_at:=until;until:=oracle2._meeting_capture_lineage_v1(m);
 m.expires_at:=until;RETURN m;
END $f$;
REVOKE ALL ON FUNCTION oracle2._meeting_capture_admission_v1(uuid,text,text,timestamptz) FROM PUBLIC,oracle2_replacement_requester;

CREATE FUNCTION oracle2.meeting_capture_transition_v1(selected uuid,seal text,expected_head integer,operation uuid,act text,body jsonb,deadline timestamptz)
 RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,oracle2 AS $f$
DECLARE m oracle2.meeting_capture_admissions_v1%ROWTYPE;h oracle2.meeting_capture_heads_v1%ROWTYPE;
 old oracle2.meeting_capture_events_v1%ROWTYPE;proof oracle2.meeting_capture_events_v1%ROWTYPE;supervisor oracle2.meeting_capture_admissions_v1%ROWTYPE;event uuid;hash text;target text;ingress uuid;required text[];field text;
BEGIN
 m:=oracle2._meeting_capture_admission_v1(selected,seal,act,deadline);
 IF operation IS NULL OR expected_head IS NULL OR expected_head<0 OR jsonb_typeof(body) IS DISTINCT FROM 'object'
 OR octet_length(body::text)>1100000 OR act NOT IN('invite','create_intent','create_observed','create_unknown','ingress','final_artifact','normalized','review','cancel','outbox','supervised','stop_intent','stop_observed','stop_unknown','stop_reconciled') THEN
  RAISE EXCEPTION 'closed bounded meeting transition required';END IF;
 required:=CASE act
 WHEN 'invite' THEN ARRAY['consent_packet_sha256'] WHEN 'create_intent' THEN ARRAY['request_sha256','supervisor_event_id','supervisor_event_sha256','supervisor_witness_sha256']
 WHEN 'supervised' THEN ARRAY['scope_sha256','create_operation_id','request_sha256','witness_sha256','witness_object_key','nonce','observed_at','valid_until','scheduler_observation_sha256']
 WHEN 'stop_intent' THEN ARRAY['create_intent_id','bot_id','create_receipt_sha256','stop_mapping_sha256','metadata_sha256']
 WHEN 'stop_observed' THEN ARRAY['stop_intent_id','wire_sha256'] WHEN 'stop_unknown' THEN ARRAY['stop_intent_id','wire_sha256']
 WHEN 'stop_reconciled' THEN ARRAY['stop_intent_id','metadata_sha256','terminal_event_id']
 WHEN 'create_observed' THEN ARRAY['intent_id','receipt_sha256','bot_id'] WHEN 'create_unknown' THEN ARRAY['intent_id','receipt_sha256']
 WHEN 'ingress' THEN ARRAY['bot_id','verifier_secret_sha256','provider_event_id','raw_sha256','byte_count','raw_object_key','event_kind']
 WHEN 'final_artifact' THEN ARRAY['selection_sha256','provider_event_id','raw_sha256','byte_count','raw_object_key','event_kind']
 WHEN 'normalized' THEN ARRAY['ingress_event_id','derivation_sha256','source_id','revision','original_sha256']
 WHEN 'review' THEN ARRAY['normalized_event_id','observation'] WHEN 'outbox' THEN ARRAY['ingress_event_id','observation']
 ELSE ARRAY[]::text[] END;
 IF NOT (body ?& required) OR body-required<>'{}'::jsonb THEN RAISE EXCEPTION 'closed meeting payload required';END IF;
 FOREACH field IN ARRAY required LOOP
  IF field IN('byte_count','revision') THEN
   IF jsonb_typeof(body->field) IS DISTINCT FROM 'number' OR body->>field !~ '^[1-9][0-9]{0,9}$' THEN RAISE EXCEPTION 'strict meeting integer required';END IF;
  ELSE
   IF jsonb_typeof(body->field) IS DISTINCT FROM 'string' OR length(btrim(body->>field)) NOT BETWEEN 1 AND 2048
    OR body->>field<>btrim(body->>field) OR body->>field~'[[:cntrl:]]' THEN RAISE EXCEPTION 'strict meeting string required';END IF;
  END IF;
 END LOOP;
 PERFORM pg_advisory_xact_lock(hashtext('oracle2-meeting:'||m.workspace_id::text||':'||m.meeting_id::text));
 hash:=encode(sha256(convert_to(oracle2._replacement_metadata_json(jsonb_build_object('action',act,'body',body)),'UTF8')),'hex');
 SELECT * INTO old FROM oracle2.meeting_capture_events_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id AND operation_id=operation;
 IF old.event_id IS NOT NULL THEN
  IF old.payload_sha256<>hash OR old.action<>act OR old.admission_id<>selected OR old.actor_id<>m.principal_id THEN RAISE EXCEPTION 'meeting operation payload collision';END IF;
  SELECT * INTO h FROM oracle2.meeting_capture_heads_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id;
  RETURN jsonb_build_object('event_id',old.event_id,'version',h.version,'state',h.state,'created',false,'valid_until',m.expires_at,'meeting_id',m.meeting_id,'capture_until',m.capture_until,'context',oracle2._replacement_private_context(oracle2._replacement_request_context(),m.expires_at));
 END IF;
 SELECT * INTO h FROM oracle2.meeting_capture_heads_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id FOR UPDATE;
 IF h.meeting_id IS NULL THEN
  IF act<>'invite' OR expected_head<>0 THEN RAISE EXCEPTION 'invitation must be committed first';END IF;
  INSERT INTO oracle2.meeting_capture_heads_v1(workspace_id,meeting_id,capture_until,version,state) VALUES(m.workspace_id,m.meeting_id,m.capture_until,0,'invited') RETURNING * INTO h;
 END IF;
 IF h.version<>expected_head OR h.version>=16384 THEN RAISE EXCEPTION 'meeting head conflict';END IF;
 IF h.state IN('UNKNOWN','cancelled') AND act NOT IN('cancel','outbox','stop_intent','stop_observed','stop_unknown','stop_reconciled') THEN RAISE EXCEPTION 'terminal meeting cannot resume';END IF;
 target:=h.state;
 CASE act
 WHEN 'invite' THEN
  IF h.version<>0 OR body<>jsonb_build_object('consent_packet_sha256',m.consent_packet_sha256) THEN RAISE EXCEPTION 'exact installed consent required';END IF;
  IF m.stop_valid_from IS NULL OR m.stop_until IS NULL OR m.stop_mapping_sha256 IS NULL
   OR NOT isfinite(m.stop_valid_from) OR NOT isfinite(m.stop_until) OR m.stop_valid_from>clock_timestamp()
   OR m.stop_until<m.capture_until OR m.stop_until>m.original_horizon
   OR m.scheduler_poll_seconds IS NULL OR m.scheduler_poll_seconds NOT BETWEEN 1 AND 30
   OR m.stop_request_seconds IS NULL OR m.stop_request_seconds NOT BETWEEN 1 AND 30
   OR m.safety_allowance_seconds IS NULL OR m.safety_allowance_seconds NOT BETWEEN 1 AND 60
   OR m.stop_margin_seconds IS NULL OR m.stop_margin_seconds NOT BETWEEN 3 AND 120
   OR m.stop_margin_seconds<m.scheduler_poll_seconds+m.stop_request_seconds+m.safety_allowance_seconds
   OR m.capture_until-make_interval(secs=>m.stop_margin_seconds)<=clock_timestamp()
   OR m.capture_until-make_interval(secs=>m.stop_margin_seconds)<=m.stop_valid_from THEN
   RAISE insufficient_privilege USING MESSAGE='preinstalled full STOP-only scheduler margin required before invitation';END IF;
 WHEN 'supervised' THEN
  IF m.supervision_scope_sha256 IS NULL OR body->>'scope_sha256' IS DISTINCT FROM m.supervision_scope_sha256
   OR body->>'request_sha256' !~ '^[a-f0-9]{64}$' OR body->>'witness_sha256' !~ '^[a-f0-9]{64}$' OR body->>'nonce' !~ '^[a-f0-9]{64}$'
   OR body->>'scheduler_observation_sha256' !~ '^[a-f0-9]{64}$'
   OR body->>'witness_object_key' IS DISTINCT FROM 'meeting-supervisor/'||m.workspace_id::text||'/'||m.meeting_id::text||'/'||(body->>'witness_sha256')||'.bin'
   OR (body->>'observed_at')::timestamptz>clock_timestamp() OR (body->>'observed_at')::timestamptz<clock_timestamp()-interval '5 seconds'
   OR NOT isfinite((body->>'valid_until')::timestamptz) OR (body->>'valid_until')::timestamptz<=clock_timestamp()
   OR (body->>'valid_until')::timestamptz>least(m.expires_at,m.capture_until,(body->>'observed_at')::timestamptz+interval '5 seconds')
   THEN RAISE insufficient_privilege USING MESSAGE='exact independently observed supervisor required';END IF;
 WHEN 'create_intent' THEN
  SELECT * INTO proof FROM oracle2.meeting_capture_events_v1 WHERE event_id=(body->>'supervisor_event_id')::uuid AND workspace_id=m.workspace_id AND meeting_id=m.meeting_id AND action='supervised' FOR SHARE;
  SELECT * INTO supervisor FROM oracle2.meeting_capture_admissions_v1 WHERE admission_id=m.supervisor_admission_id FOR SHARE;
  IF supervisor.admission_id IS NULL OR supervisor.principal_id=m.principal_id OR supervisor.supervision_scope_sha256 IS DISTINCT FROM m.supervision_scope_sha256
   OR proof.admission_id IS DISTINCT FROM supervisor.admission_id OR proof.actor_id IS DISTINCT FROM supervisor.principal_id
   OR proof.payload_sha256 IS DISTINCT FROM body->>'supervisor_event_sha256' OR proof.payload->>'witness_sha256' IS DISTINCT FROM body->>'supervisor_witness_sha256'
   OR proof.payload->>'scope_sha256' IS DISTINCT FROM m.supervision_scope_sha256 OR proof.payload->>'create_operation_id' IS DISTINCT FROM operation::text
   OR proof.payload->>'request_sha256' IS DISTINCT FROM body->>'request_sha256' OR (proof.payload->>'valid_until')::timestamptz<=clock_timestamp()
   OR supervisor.valid_from>clock_timestamp() OR supervisor.expires_at<=clock_timestamp() OR supervisor.capture_until IS DISTINCT FROM m.capture_until
   OR EXISTS(SELECT 1 FROM oracle2.meeting_capture_revocations_v1 WHERE admission_id=supervisor.admission_id) THEN
   RAISE insufficient_privilege USING MESSAGE='fresh independently installed supervisor receipt required';END IF;
  IF NOT EXISTS(SELECT 1 FROM oracle2.hosting_request_principal_admissions a JOIN oracle2.hosting_role_runtime_admissions r USING(role_name)
   JOIN pg_roles role ON role.rolname=a.role_name
   WHERE a.role_name=supervisor.role_name AND a.principal_id=supervisor.principal_id AND a.workspace_id=m.workspace_id
   AND a.runtime_hash=supervisor.runtime_hash AND a.registry_hash=supervisor.registry_hash AND r.runtime_hash=a.runtime_hash AND r.registry_hash=a.registry_hash
   AND a.expires_at>clock_timestamp() AND r.expires_at>clock_timestamp() AND isfinite(r.expires_at)
   AND role.rolcanlogin AND NOT(role.rolsuper OR role.rolcreatedb OR role.rolcreaterole OR role.rolreplication OR role.rolbypassrls)) THEN
   RAISE insufficient_privilege USING MESSAGE='current independent supervisor runtime required';END IF;
  supervisor.expires_at:=least(supervisor.expires_at,(proof.payload->>'valid_until')::timestamptz);
  PERFORM oracle2._meeting_capture_lineage_v1(supervisor);
  IF h.state<>'invited' OR h.create_intent_id IS NOT NULL OR NOT(body ? 'request_sha256') OR body-ARRAY['request_sha256','supervisor_event_id','supervisor_event_sha256','supervisor_witness_sha256']<>'{}'::jsonb
  OR body->>'request_sha256' !~ '^[a-f0-9]{64}$' THEN RAISE EXCEPTION 'single exact create intent required';END IF;
  target:='joining';h.create_intent_id:=operation;
 WHEN 'create_observed','create_unknown' THEN
  IF h.state<>'joining' OR body->>'intent_id' IS DISTINCT FROM h.create_intent_id::text OR (act='create_unknown' AND body-ARRAY['intent_id','receipt_sha256']<>'{}'::jsonb) OR (act='create_observed' AND (body-ARRAY['intent_id','receipt_sha256','bot_id']<>'{}'::jsonb OR body->>'bot_id' !~ '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$'))
  OR body->>'receipt_sha256' !~ '^[a-f0-9]{64}$' THEN RAISE EXCEPTION 'exact observed create receipt required';END IF;
  target:=CASE WHEN act='create_unknown' THEN 'UNKNOWN' ELSE 'pending_mapping' END;
 WHEN 'stop_intent' THEN
  SELECT * INTO proof FROM oracle2.meeting_capture_events_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id AND action='create_observed' ORDER BY version DESC LIMIT 1 FOR SHARE;
  IF h.stop_intent_id IS NOT NULL OR h.create_intent_id IS NULL OR proof.event_id IS NULL
   OR body->>'create_intent_id' IS DISTINCT FROM h.create_intent_id::text
   OR proof.payload->>'intent_id' IS DISTINCT FROM h.create_intent_id::text
   OR body->>'bot_id' IS DISTINCT FROM proof.payload->>'bot_id'
   OR body->>'create_receipt_sha256' IS DISTINCT FROM proof.payload->>'receipt_sha256'
   OR body->>'stop_mapping_sha256' IS DISTINCT FROM m.stop_mapping_sha256
   OR body->>'metadata_sha256' !~ '^[a-f0-9]{64}$'
   OR clock_timestamp()<m.capture_until-make_interval(secs=>m.stop_margin_seconds) THEN
   RAISE insufficient_privilege USING MESSAGE='single due exact-bot independently mapped STOP intent required';END IF;
  h.stop_intent_id:=operation;h.stop_state:='inflight';h.capture_open:=false;target:='capture_ended';
 WHEN 'stop_observed','stop_unknown' THEN
  IF h.stop_state<>'inflight' OR h.stop_intent_id IS NULL OR body->>'stop_intent_id' IS DISTINCT FROM h.stop_intent_id::text
   OR body->>'wire_sha256' !~ '^[a-f0-9]{64}$' THEN RAISE EXCEPTION 'single exact STOP observation required';END IF;
  h.stop_observation_id:=operation;h.stop_state:=CASE WHEN act='stop_unknown' THEN 'UNKNOWN' ELSE 'observed' END;
  target:='capture_status_unknown';
 WHEN 'ingress' THEN
  IF m.bot_id IS NULL OR body->>'bot_id' IS DISTINCT FROM m.bot_id OR body->>'verifier_secret_sha256' IS DISTINCT FROM m.verifier_secret_sha256
   OR body-ARRAY['bot_id','verifier_secret_sha256','provider_event_id','raw_sha256','byte_count','raw_object_key','event_kind']<>'{}'::jsonb
   OR jsonb_typeof(body->'provider_event_id') IS DISTINCT FROM 'string' OR length(body->>'provider_event_id') NOT BETWEEN 1 AND 256
   OR body->>'raw_sha256' !~ '^[a-f0-9]{64}$' OR jsonb_typeof(body->'byte_count') IS DISTINCT FROM 'number'
   OR body->>'byte_count' !~ '^[1-9][0-9]{0,6}$' OR (body->>'byte_count')::integer>1048576
   OR body->>'raw_object_key' IS DISTINCT FROM 'meeting-raw/'||m.workspace_id::text||'/'||m.meeting_id::text||'/'||(body->>'raw_sha256')||'.bin'
   OR (body->>'event_kind' NOT IN('transcript.data','transcript.partial_data','transcript.done','transcript.failed') AND body->>'event_kind' !~ '^bot\.[a-z_]{1,64}$')
   OR cardinality(h.pending_ingress)+cardinality(h.processed_ingress)>=4096 THEN RAISE EXCEPTION 'exact bounded installed ingress required';END IF;
  SELECT * INTO old FROM oracle2.meeting_capture_events_v1 WHERE provider=m.provider AND provider_account=m.provider_account AND provider_event_id=body->>'provider_event_id';
  IF old.event_id IS NOT NULL THEN RAISE EXCEPTION 'provider identity collision';END IF;
  target:=CASE body->>'event_kind' WHEN 'transcript.failed' THEN 'failed' WHEN 'bot.fatal' THEN 'failed' WHEN 'bot.in_waiting_room' THEN 'waiting_room' WHEN 'bot.joining_call' THEN 'joining' WHEN 'bot.in_call_not_recording' THEN 'recording_permission_pending' WHEN 'bot.recording_permission_denied' THEN 'recording_permission_denied' WHEN 'bot.recording_permission_allowed' THEN 'recording_permission_pending' WHEN 'bot.in_call_recording' THEN 'capturing' WHEN 'transcript.data' THEN 'capturing' WHEN 'transcript.partial_data' THEN 'capturing' WHEN 'bot.call_ended' THEN 'capture_ended' WHEN 'bot.done' THEN 'final_artifact_pending' WHEN 'transcript.done' THEN 'final_artifact_pending' ELSE 'capture_status_unknown' END;
  h.capture_open:=target='capturing';
 WHEN 'final_artifact' THEN
  IF m.final_artifact_sha256 IS NULL OR body->>'selection_sha256' IS DISTINCT FROM m.final_artifact_sha256
   OR body->>'raw_sha256' !~ '^[a-f0-9]{64}$' OR (body->>'byte_count')::numeric NOT BETWEEN 1 AND 1048576
   OR body->>'raw_object_key' IS DISTINCT FROM 'meeting-raw/'||m.workspace_id::text||'/'||m.meeting_id::text||'/'||(body->>'raw_sha256')||'.bin'
   OR body->>'event_kind' IS DISTINCT FROM m.provider||'.final' OR length(body->>'provider_event_id')>256
   OR cardinality(h.pending_ingress)+cardinality(h.processed_ingress)>=4096 THEN RAISE EXCEPTION 'exact installed final artifact required';END IF;
  target:='processing';h.capture_open:=false;
 WHEN 'normalized' THEN
  IF body-ARRAY['ingress_event_id','derivation_sha256','source_id','revision','original_sha256']<>'{}'::jsonb
   OR body->>'derivation_sha256' !~ '^[a-f0-9]{64}$' OR body->>'original_sha256' !~ '^[a-f0-9]{64}$'
   OR NOT ((body->>'ingress_event_id')::uuid=ANY(h.pending_ingress)) THEN RAISE EXCEPTION 'exact retained ingress derivation required';END IF;
  ingress:=(body->>'ingress_event_id')::uuid;
  IF NOT EXISTS(SELECT 1 FROM oracle2.meeting_capture_events_v1 e WHERE e.event_id=ingress AND e.workspace_id=m.workspace_id AND e.meeting_id=m.meeting_id AND e.action='final_artifact' AND e.payload->>'selection_sha256'=m.final_artifact_sha256 AND e.payload->>'event_kind'=m.provider||'.final') THEN RAISE EXCEPTION 'whole-final selected parent required';END IF;
  IF NOT EXISTS(SELECT 1 FROM oracle2.source_original_revisions o JOIN oracle2.sources s ON s.workspace_id=o.workspace_id AND s.source_id=o.source_id
    WHERE o.workspace_id=m.workspace_id AND o.source_id=(body->>'source_id')::uuid AND o.revision=(body->>'revision')::integer
    AND o.original_sha256=body->>'original_sha256' AND o.media_type='text/plain' AND s.revision=o.revision AND s.status IN('processing','draft','confirmed') AND NOT EXISTS(SELECT 1 FROM oracle2.source_original_withdrawals_v1 w WHERE w.workspace_id=o.workspace_id AND w.source_id=o.source_id AND w.revision=o.revision)) THEN
   RAISE EXCEPTION 'current retained native text required';END IF;
  target:='review';h.pending_ingress:=array_remove(h.pending_ingress,ingress);h.processed_ingress:=array_append(h.processed_ingress,ingress);
 WHEN 'review' THEN
  IF h.state<>'review' OR body-ARRAY['normalized_event_id','observation']<>'{}'::jsonb
   OR body->>'normalized_event_id' IS DISTINCT FROM h.last_normalized_event_id::text OR body->>'observation' NOT IN('reported','needs_correction','unknown') THEN RAISE EXCEPTION 'reported-only meeting review required';END IF;
 WHEN 'cancel' THEN
  IF body<>'{}'::jsonb THEN RAISE EXCEPTION 'closed local cancel required';END IF;target:='cancelled';
 WHEN 'outbox' THEN
  IF body-ARRAY['ingress_event_id','observation']<>'{}'::jsonb
   OR NOT ((body->>'ingress_event_id')::uuid=ANY(h.pending_ingress)) OR body->>'observation' NOT IN('enqueued','enqueue_failed') THEN RAISE EXCEPTION 'exact durable outbox observation required';END IF;
 ELSE RAISE EXCEPTION 'closed meeting transition required';
 END CASE;
 event:=operation;
 INSERT INTO oracle2.meeting_capture_events_v1 VALUES(event,m.workspace_id,m.meeting_id,h.version+1,m.admission_id,m.principal_id,act,hash,body,operation,
 CASE WHEN act IN('ingress','final_artifact') THEN m.provider END,CASE WHEN act IN('ingress','final_artifact') THEN m.provider_account END,CASE WHEN act IN('ingress','final_artifact') THEN body->>'provider_event_id' END,clock_timestamp());
 IF act IN('ingress','final_artifact') THEN h.pending_ingress:=array_append(h.pending_ingress,event);IF h.capture_open THEN h.last_capture_event_id:=event;END IF;END IF;
 IF act='cancel' THEN h.capture_open:=false;END IF;
 IF act='normalized' THEN h.last_normalized_event_id:=event;END IF;
 UPDATE oracle2.meeting_capture_heads_v1 SET version=h.version+1,state=target,pending_ingress=h.pending_ingress,processed_ingress=h.processed_ingress,
 last_event_id=event,last_normalized_event_id=h.last_normalized_event_id,create_intent_id=h.create_intent_id,last_capture_event_id=h.last_capture_event_id,capture_open=h.capture_open,stop_intent_id=h.stop_intent_id,stop_observation_id=h.stop_observation_id,stop_state=h.stop_state WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id;
 -- Reprove original admission after transition and before caller commit.
 PERFORM oracle2._meeting_capture_admission_v1(selected,seal,act,deadline);
 RETURN jsonb_build_object('event_id',event,'version',h.version+1,'state',target,'created',true,'valid_until',m.expires_at,'meeting_id',m.meeting_id,'capture_until',m.capture_until,'context',oracle2._replacement_private_context(oracle2._replacement_request_context(),m.expires_at));
END $f$;
REVOKE ALL ON FUNCTION oracle2.meeting_capture_transition_v1(uuid,text,integer,uuid,text,jsonb,timestamptz) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION oracle2.meeting_capture_transition_v1(uuid,text,integer,uuid,text,jsonb,timestamptz) TO oracle2_replacement_requester;

CREATE FUNCTION oracle2.meeting_capture_read_v1(selected uuid,seal text,act text,deadline timestamptz)
 RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,oracle2 AS $f$
DECLARE m oracle2.meeting_capture_admissions_v1%ROWTYPE;h oracle2.meeting_capture_heads_v1%ROWTYPE;events jsonb;
BEGIN
 IF act NOT IN('status','process','ingress','final_artifact','supervise') THEN RAISE EXCEPTION 'fixed meeting read required';END IF;
 m:=oracle2._meeting_capture_admission_v1(selected,seal,act,deadline);
 SELECT * INTO h FROM oracle2.meeting_capture_heads_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id FOR SHARE;

 RETURN jsonb_build_object('meeting_id',m.meeting_id,'version',coalesce(h.version,0),'state',coalesce(h.state,'not_invited'),
 'pending_ingress',coalesce(h.pending_ingress,'{}'::uuid[]),'supervision_binding',CASE WHEN act='supervise' THEN jsonb_build_object('scope_sha256',m.supervision_scope_sha256,'capture_until',m.capture_until,'create_operation_id',h.create_intent_id,'create_request_sha256',(SELECT e.payload->>'request_sha256' FROM oracle2.meeting_capture_events_v1 e WHERE e.event_id=h.create_intent_id),'created_bot',(SELECT jsonb_build_object('bot_id',e.payload->>'bot_id','receipt_sha256',e.payload->>'receipt_sha256','event_id',e.event_id) FROM oracle2.meeting_capture_events_v1 e WHERE e.workspace_id=m.workspace_id AND e.meeting_id=m.meeting_id AND e.action='create_observed' ORDER BY e.version DESC LIMIT 1)) ELSE NULL END,'capture_until',m.capture_until,'valid_until',m.expires_at,'context',oracle2._replacement_private_context(oracle2._replacement_request_context(),m.expires_at),'ingress_binding',CASE WHEN act='ingress' THEN jsonb_build_object('provider',m.provider,'provider_account',m.provider_account,'tenant_id',m.tenant_id,'provider_meeting_id',m.provider_meeting_id,'bot_id',m.bot_id,'verifier_secret_sha256',m.verifier_secret_sha256) ELSE NULL END,'artifact_binding',CASE WHEN act='final_artifact' THEN jsonb_build_object('provider',m.provider,'provider_account',m.provider_account,'tenant_id',m.tenant_id,'provider_meeting_id',m.provider_meeting_id,'bot_id',m.bot_id,'selection_sha256',m.final_artifact_sha256) ELSE NULL END);
END $f$;
REVOKE ALL ON FUNCTION oracle2.meeting_capture_read_v1(uuid,text,text,timestamptz) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION oracle2.meeting_capture_read_v1(uuid,text,text,timestamptz) TO oracle2_replacement_requester;

-- Ingress provenance and pending work are reopened by opaque identity only.
CREATE FUNCTION oracle2.meeting_capture_receipt_v1(selected uuid,seal text,wanted uuid,act text,deadline timestamptz)
 RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,oracle2 AS $f$
DECLARE m oracle2.meeting_capture_admissions_v1%ROWTYPE;e oracle2.meeting_capture_events_v1%ROWTYPE;
BEGIN
 IF act NOT IN('process','ingress','final_artifact') THEN RAISE EXCEPTION 'fixed receipt purpose required';END IF;
 m:=oracle2._meeting_capture_admission_v1(selected,seal,act,deadline);
 SELECT * INTO e FROM oracle2.meeting_capture_events_v1 WHERE event_id=wanted AND workspace_id=m.workspace_id AND meeting_id=m.meeting_id AND action IN('ingress','final_artifact');
 IF e.event_id IS NULL AND act='process' THEN RAISE insufficient_privilege USING MESSAGE='retained meeting receipt denied';END IF;
 IF e.event_id IS NOT NULL AND (e.provider<>m.provider OR e.provider_account<>m.provider_account) THEN RAISE insufficient_privilege USING MESSAGE='retained meeting receipt denied';END IF;
 RETURN jsonb_build_object('event_id',wanted,'payload',e.payload,'payload_sha256',e.payload_sha256,'action',e.action,'valid_until',m.expires_at,'meeting_id',m.meeting_id,'capture_until',m.capture_until,'context',oracle2._replacement_private_context(oracle2._replacement_request_context(),m.expires_at));
END $f$;
REVOKE ALL ON FUNCTION oracle2.meeting_capture_receipt_v1(uuid,text,uuid,text,timestamptz) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION oracle2.meeting_capture_receipt_v1(uuid,text,uuid,text,timestamptz) TO oracle2_replacement_requester;
-- Revocation shares the same workspace serialization as the current runtime owner.
CREATE FUNCTION oracle2._meeting_capture_revoke_lock_v1() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog,oracle2 AS $f$
DECLARE workspace uuid;BEGIN
 SELECT workspace_id INTO workspace FROM oracle2.meeting_capture_admissions_v1 WHERE admission_id=NEW.admission_id;
 PERFORM pg_advisory_xact_lock(hashtext('oracle2-authz:'||workspace::text));RETURN NEW;
END $f$;
REVOKE ALL ON FUNCTION oracle2._meeting_capture_revoke_lock_v1() FROM PUBLIC;
CREATE TRIGGER meeting_capture_revocation_lock BEFORE INSERT ON oracle2.meeting_capture_revocations_v1 FOR EACH ROW EXECUTE FUNCTION oracle2._meeting_capture_revoke_lock_v1();

-- Frozen private consumption boundary for S08; no public EXECUTE grant.
CREATE FUNCTION oracle2._meeting_capture_current_v1(selected uuid,seal text,deadline timestamptz)
 RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,oracle2 AS $f$
DECLARE m oracle2.meeting_capture_admissions_v1%ROWTYPE;h oracle2.meeting_capture_heads_v1%ROWTYPE;e oracle2.meeting_capture_events_v1%ROWTYPE;
BEGIN
 m:=oracle2._meeting_capture_admission_v1(selected,seal,'status',deadline);
 SELECT * INTO h FROM oracle2.meeting_capture_heads_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id FOR SHARE;
 SELECT * INTO e FROM oracle2.meeting_capture_events_v1 WHERE event_id=h.last_capture_event_id AND workspace_id=m.workspace_id AND meeting_id=m.meeting_id;
 IF m.bot_id IS NULL OR m.verifier_secret_sha256 IS NULL OR h.meeting_id IS NULL OR NOT h.capture_open OR h.state<>'capturing'
 OR m.capture_until<=clock_timestamp() OR e.event_id IS NULL OR e.action<>'ingress' OR e.provider<>m.provider OR e.provider_account<>m.provider_account
 OR e.payload->>'bot_id' IS DISTINCT FROM m.bot_id OR e.payload->>'verifier_secret_sha256' IS DISTINCT FROM m.verifier_secret_sha256 THEN
  RAISE insufficient_privilege USING MESSAGE='current invited capture denied';
 END IF;
 RETURN jsonb_build_object('workspace_id',m.workspace_id,'meeting_id',m.meeting_id,'provider',m.provider,'provider_account',m.provider_account,
  'tenant_id',m.tenant_id,'provider_meeting_id',m.provider_meeting_id,'bot_id',m.bot_id,'admission_id',m.admission_id,'admission_sha256',m.admission_sha256,
  'capture_event_id',e.event_id,'capture_event_sha256',e.payload_sha256,'capture_revision',h.version,'valid_until',least(m.expires_at,m.capture_until));
END $f$;
REVOKE ALL ON FUNCTION oracle2._meeting_capture_current_v1(uuid,text,timestamptz) FROM PUBLIC,oracle2_replacement_requester;

CREATE FUNCTION oracle2._meeting_capture_end_immutable_v1() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog,oracle2 AS $f$
BEGIN IF NEW.capture_until IS DISTINCT FROM OLD.capture_until THEN RAISE EXCEPTION 'original capture end immutable';END IF;RETURN NEW;END $f$;
REVOKE ALL ON FUNCTION oracle2._meeting_capture_end_immutable_v1() FROM PUBLIC;
CREATE TRIGGER meeting_capture_end_immutable BEFORE UPDATE ON oracle2.meeting_capture_heads_v1 FOR EACH ROW EXECUTE FUNCTION oracle2._meeting_capture_end_immutable_v1();

-- Rooted workspace membership only. This never proves employee identity.
CREATE FUNCTION oracle2._meeting_workspace_actor_current_v1(workspace uuid,actor uuid,deadline timestamptz)
 RETURNS timestamptz LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,oracle2 AS $f$
DECLARE a oracle2.hosting_request_principal_admissions%ROWTYPE;candidate oracle2.appointments%ROWTYPE;p oracle2.appointments%ROWTYPE;
 until timestamptz:=deadline;branch_until timestamptz;seen uuid[];
BEGIN
 FOR a IN SELECT * FROM oracle2.hosting_request_principal_admissions WHERE principal_id=actor FOR SHARE LOOP
  IF a.workspace_id<>workspace OR a.expires_at<=clock_timestamp() OR NOT EXISTS(
   SELECT 1 FROM oracle2.hosting_role_runtime_admissions r JOIN pg_roles role ON role.rolname=r.role_name
   WHERE r.role_name=a.role_name AND r.runtime_hash=a.runtime_hash AND r.registry_hash=a.registry_hash AND isfinite(r.expires_at) AND r.expires_at>clock_timestamp()
   AND role.rolcanlogin AND NOT(role.rolsuper OR role.rolcreatedb OR role.rolcreaterole OR role.rolreplication OR role.rolbypassrls)) THEN
   RAISE insufficient_privilege USING MESSAGE='contradictory current participant principal denied';END IF;
  until:=least(until,a.expires_at,(SELECT r.expires_at FROM oracle2.hosting_role_runtime_admissions r WHERE r.role_name=a.role_name));
 END LOOP;
 <<candidate_loop>>
 FOR candidate IN SELECT * FROM oracle2.appointments WHERE workspace_id=workspace AND actor_id=actor ORDER BY appointment_id FOR SHARE LOOP
  p:=candidate;seen:='{}';branch_until:=until;
  LOOP
   IF p.appointment_id=ANY(seen) OR cardinality(seen)>=16 OR p.workspace_id<>workspace OR p.revoked_at IS NOT NULL
    OR (p.expires_at IS NOT NULL AND (NOT isfinite(p.expires_at) OR p.expires_at<=clock_timestamp())) THEN CONTINUE candidate_loop;END IF;
   seen:=array_append(seen,p.appointment_id);branch_until:=least(branch_until,coalesce(p.expires_at,branch_until));
   IF p.parent_id IS NULL THEN
    IF p.scope='root' AND branch_until>clock_timestamp() THEN RETURN branch_until;END IF;
    CONTINUE candidate_loop;
   END IF;
   SELECT parent.* INTO p FROM oracle2.appointments parent WHERE parent.appointment_id=p.parent_id AND parent.actor_id=p.granted_by FOR SHARE;
   IF p.appointment_id IS NULL THEN CONTINUE candidate_loop;END IF;
  END LOOP;
 END LOOP;
 RAISE insufficient_privilege USING MESSAGE='current rooted workspace participant denied';
END $f$;
REVOKE ALL ON FUNCTION oracle2._meeting_workspace_actor_current_v1(uuid,uuid,timestamptz) FROM PUBLIC,oracle2_replacement_requester;
CREATE FUNCTION oracle2._meeting_participant_epoch_current_v1(m oracle2.meeting_capture_admissions_v1,deadline timestamptz)
 RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,oracle2 AS $f$
DECLARE e oracle2.meeting_participant_epochs_v1%ROWTYPE;p jsonb;link jsonb;until timestamptz;
BEGIN
 SELECT * INTO e FROM oracle2.meeting_participant_epochs_v1 WHERE epoch_id=m.participant_epoch_id FOR SHARE;
 p:=e.epoch_payload;
 IF e.epoch_id IS NULL OR e.epoch_sha256 IS DISTINCT FROM m.participant_epoch_sha256 OR e.workspace_id<>m.workspace_id OR e.meeting_id<>m.meeting_id
  OR p->>'provider' IS DISTINCT FROM m.provider OR p->>'provider_account' IS DISTINCT FROM m.provider_account OR p->>'tenant_id' IS DISTINCT FROM m.tenant_id
  OR p->>'provider_meeting_id' IS DISTINCT FROM m.provider_meeting_id OR p->>'bot_id' IS DISTINCT FROM m.bot_id
  OR (p->>'capture_until')::timestamptz IS DISTINCT FROM m.capture_until
  OR (p->>'issuer_actor')::uuid=m.principal_id OR (p->>'reviewer_actor')::uuid=m.principal_id OR p->>'issuer_actor'=p->>'reviewer_actor'
  OR (p->>'valid_from')::timestamptz>clock_timestamp() OR (p->>'expires_at')::timestamptz<=clock_timestamp()
  OR NOT isfinite((p->>'expires_at')::timestamptz) OR (p->>'expires_at')::timestamptz>m.capture_until
  OR EXISTS(SELECT 1 FROM oracle2.meeting_participant_epoch_revocations_v1 WHERE epoch_id=e.epoch_id)
  OR EXISTS(SELECT 1 FROM oracle2.meeting_participant_epochs_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id AND epoch_revision>e.epoch_revision)
  OR jsonb_typeof(p->'links') IS DISTINCT FROM 'array' OR jsonb_array_length(p->'links') NOT BETWEEN 1 AND 4096 THEN
  RAISE insufficient_privilege USING MESSAGE='current exact participant epoch denied';END IF;
 until:=least(deadline,m.expires_at,m.capture_until,(p->>'expires_at')::timestamptz);
 FOR link IN SELECT value FROM jsonb_array_elements(p->'links') LOOP
  IF link->>'attribution'='workspace_actor' THEN until:=least(until,oracle2._meeting_workspace_actor_current_v1(m.workspace_id,(link->>'actor_id')::uuid,until));END IF;
 END LOOP;
 RETURN jsonb_build_object('epoch',p,'epoch_sha256',e.epoch_sha256,'valid_until',until);
END $f$;
REVOKE ALL ON FUNCTION oracle2._meeting_participant_epoch_current_v1(oracle2.meeting_capture_admissions_v1,timestamptz) FROM PUBLIC,oracle2_replacement_requester;

-- Meeting-only current finalized utterance consumer. No shared-source or send
-- grant: an independently installed explicit participant_turn action is needed.
CREATE FUNCTION oracle2.meeting_capture_current_turn_v1(selected uuid,seal text,wanted uuid,deadline timestamptz)
 RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,oracle2 AS $f$
DECLARE m oracle2.meeting_capture_admissions_v1%ROWTYPE;c jsonb;epoch jsonb;e oracle2.meeting_capture_events_v1%ROWTYPE;
BEGIN
 m:=oracle2._meeting_capture_admission_v1(selected,seal,'participant_turn',deadline);
 c:=oracle2._meeting_capture_current_v1(selected,seal,deadline);
 epoch:=oracle2._meeting_participant_epoch_current_v1(m,deadline);
 IF wanted IS NULL OR wanted::text IS DISTINCT FROM c->>'capture_event_id' THEN RAISE insufficient_privilege USING MESSAGE='exact latest current participant turn required';END IF;
 SELECT * INTO e FROM oracle2.meeting_capture_events_v1 WHERE event_id=wanted AND workspace_id=m.workspace_id AND meeting_id=m.meeting_id AND action='ingress' FOR SHARE;
 IF e.event_id IS NULL OR e.payload->>'event_kind' IS DISTINCT FROM 'transcript.data' THEN RAISE insufficient_privilege USING MESSAGE='finalized current utterance required';END IF;
 RETURN jsonb_build_object('capture',c,'epoch',epoch->'epoch','epoch_sha256',epoch->>'epoch_sha256','valid_until',epoch->>'valid_until','receipt',jsonb_build_object('event_id',wanted,'payload',e.payload,'payload_sha256',e.payload_sha256,'action',e.action,'valid_until',least(m.expires_at,m.capture_until),'meeting_id',m.meeting_id,'capture_until',m.capture_until,'context',oracle2._replacement_private_context(oracle2._replacement_request_context(),least(m.expires_at,m.capture_until))));
END $f$;
REVOKE ALL ON FUNCTION oracle2.meeting_capture_current_turn_v1(uuid,text,uuid,timestamptz) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION oracle2.meeting_capture_current_turn_v1(uuid,text,uuid,timestamptz) TO oracle2_replacement_requester;

CREATE FUNCTION oracle2._meeting_participant_epoch_change_lock_v1() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog,oracle2 AS $f$
DECLARE workspace uuid;BEGIN
 IF TG_TABLE_NAME='meeting_participant_epochs_v1' THEN workspace:=NEW.workspace_id;
 ELSIF TG_TABLE_NAME='meeting_participant_epoch_revocations_v1' THEN SELECT workspace_id INTO workspace FROM oracle2.meeting_participant_epochs_v1 WHERE epoch_id=NEW.epoch_id;
 ELSE RAISE EXCEPTION 'fixed participant epoch installation table required';END IF;
 IF workspace IS NULL THEN RAISE EXCEPTION 'exact participant epoch workspace required';END IF;
 PERFORM pg_advisory_xact_lock(hashtext('oracle2-authz:'||workspace::text));RETURN NEW;
END $f$;
REVOKE ALL ON FUNCTION oracle2._meeting_participant_epoch_change_lock_v1() FROM PUBLIC;
CREATE TRIGGER participant_epoch_install_lock BEFORE INSERT ON oracle2.meeting_participant_epochs_v1 FOR EACH ROW EXECUTE FUNCTION oracle2._meeting_participant_epoch_change_lock_v1();
CREATE TRIGGER participant_epoch_revoke_lock BEFORE INSERT ON oracle2.meeting_participant_epoch_revocations_v1 FOR EACH ROW EXECUTE FUNCTION oracle2._meeting_participant_epoch_change_lock_v1();

-- One installed meeting's actual due queue; never a caller-created liveness flag.
CREATE FUNCTION oracle2.meeting_capture_due_stop_v1(selected uuid,seal text,deadline timestamptz)
 RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,oracle2 AS $f$
DECLARE m oracle2.meeting_capture_admissions_v1%ROWTYPE;h oracle2.meeting_capture_heads_v1%ROWTYPE;created oracle2.meeting_capture_events_v1%ROWTYPE;due_at timestamptz;
BEGIN
 m:=oracle2._meeting_capture_admission_v1(selected,seal,'supervise',deadline);
 SELECT * INTO h FROM oracle2.meeting_capture_heads_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id FOR SHARE;
 IF h.meeting_id IS NULL OR m.stop_margin_seconds IS NULL OR m.stop_until IS NULL OR m.stop_until>m.original_horizon THEN RAISE insufficient_privilege USING MESSAGE='actual independently installed due-stop queue missing';END IF;
 SELECT * INTO created FROM oracle2.meeting_capture_events_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id AND action='create_observed' ORDER BY version DESC LIMIT 1 FOR SHARE;
 due_at:=m.capture_until-make_interval(secs=>m.stop_margin_seconds);
 RETURN jsonb_build_object('workspace_id',m.workspace_id,'meeting_id',m.meeting_id,'version',h.version,'capture_until',m.capture_until,'stop_valid_from',m.stop_valid_from,'stop_until',m.stop_until,'original_horizon',m.original_horizon,'due_at',due_at,'due',created.event_id IS NOT NULL AND clock_timestamp()>=due_at,'create_intent_id',h.create_intent_id,'created_bot',created.payload,'stop_intent_id',h.stop_intent_id,'stop_observation_id',h.stop_observation_id,'stop_state',h.stop_state,'stop_mapping_sha256',m.stop_mapping_sha256,'scheduler_poll_seconds',m.scheduler_poll_seconds,'stop_request_seconds',m.stop_request_seconds,'safety_allowance_seconds',m.safety_allowance_seconds,'stop_margin_seconds',m.stop_margin_seconds,'valid_until',m.expires_at,'context',oracle2._replacement_private_context(oracle2._replacement_request_context(),m.expires_at));
END $f$;
REVOKE ALL ON FUNCTION oracle2.meeting_capture_due_stop_v1(uuid,text,timestamptz) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION oracle2.meeting_capture_due_stop_v1(uuid,text,timestamptz) TO oracle2_replacement_requester;

-- Exact selected final raw mapping; same current workspace actor boundary as live.
CREATE FUNCTION oracle2.meeting_capture_current_final_mapping_v1(selected uuid,seal text,wanted uuid,deadline timestamptz)
 RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,oracle2 AS $f$
DECLARE m oracle2.meeting_capture_admissions_v1%ROWTYPE;row oracle2.meeting_final_mappings_v1%ROWTYPE;e oracle2.meeting_capture_events_v1%ROWTYPE;body jsonb;link jsonb;until timestamptz;actor_end timestamptz;
BEGIN
 m:=oracle2._meeting_capture_admission_v1(selected,seal,'process',deadline);
 SELECT * INTO e FROM oracle2.meeting_capture_events_v1 WHERE event_id=wanted AND workspace_id=m.workspace_id AND meeting_id=m.meeting_id AND action='final_artifact' FOR SHARE;
 SELECT * INTO row FROM oracle2.meeting_final_mappings_v1 WHERE mapping_id=m.final_mapping_id AND workspace_id=m.workspace_id AND meeting_id=m.meeting_id FOR SHARE;
 IF e.event_id IS NULL OR e.payload->>'selection_sha256' IS DISTINCT FROM m.final_artifact_sha256 OR row.mapping_id IS NULL
  OR row.mapping_sha256 IS DISTINCT FROM m.final_mapping_sha256 OR row.raw_sha256 IS DISTINCT FROM e.payload->>'raw_sha256'
  OR EXISTS(SELECT 1 FROM oracle2.meeting_final_mapping_revocations_v1 WHERE mapping_id=row.mapping_id)
  OR EXISTS(SELECT 1 FROM oracle2.meeting_final_mappings_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id AND raw_sha256=row.raw_sha256 AND mapping_revision>row.mapping_revision) THEN RAISE insufficient_privilege USING MESSAGE='exact current final mapping denied';END IF;
 body:=row.mapping_payload;
 IF body->>'provider' IS DISTINCT FROM m.provider OR body->>'provider_account' IS DISTINCT FROM m.provider_account OR body->>'tenant_id' IS DISTINCT FROM m.tenant_id OR body->>'provider_meeting_id' IS DISTINCT FROM m.provider_meeting_id
  OR (body->>'issuer_actor')::uuid=(body->>'reviewer_actor')::uuid OR m.principal_id IN((body->>'issuer_actor')::uuid,(body->>'reviewer_actor')::uuid)
  OR NOT isfinite((body->>'expires_at')::timestamptz) OR NOT isfinite((body->>'original_horizon')::timestamptz)
  OR (body->>'valid_from')::timestamptz>clock_timestamp() OR (body->>'expires_at')::timestamptz<=clock_timestamp()
  OR (body->>'expires_at')::timestamptz>(body->>'original_horizon')::timestamptz OR (body->>'original_horizon')::timestamptz>m.original_horizon
  OR jsonb_typeof(body->'links') IS DISTINCT FROM 'array' OR jsonb_array_length(body->'links') NOT BETWEEN 1 AND 4096 THEN RAISE insufficient_privilege USING MESSAGE='independent finite final workspace mapping required';END IF;
 until:=least(m.expires_at,(body->>'expires_at')::timestamptz,(body->>'original_horizon')::timestamptz);
 FOR link IN SELECT value FROM jsonb_array_elements(body->'links') LOOP
  IF link->>'attribution'='workspace_actor' THEN
   actor_end:=oracle2._meeting_workspace_actor_current_v1(m.workspace_id,(link->>'actor_id')::uuid,until);until:=least(until,actor_end);
  ELSIF link->>'attribution' NOT IN('unknown','oracle') OR link->'actor_id'<>'null'::jsonb THEN RAISE insufficient_privilege USING MESSAGE='whole-final employee or guessed actor denied';END IF;
 END LOOP;
 IF until<=clock_timestamp() THEN RAISE insufficient_privilege USING MESSAGE='final workspace mapping elapsed';END IF;
 RETURN jsonb_build_object('receipt',oracle2.meeting_capture_receipt_v1(selected,seal,wanted,'process',deadline),'mapping',body,'mapping_sha256',row.mapping_sha256,'valid_until',until);
END $f$;
REVOKE ALL ON FUNCTION oracle2.meeting_capture_current_final_mapping_v1(uuid,text,uuid,timestamptz) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION oracle2.meeting_capture_current_final_mapping_v1(uuid,text,uuid,timestamptz) TO oracle2_replacement_requester;
CREATE FUNCTION oracle2._meeting_final_mapping_lock_v1() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog,oracle2 AS $f$
DECLARE workspace uuid;BEGIN
 IF TG_TABLE_NAME='meeting_final_mappings_v1' THEN workspace:=NEW.workspace_id;ELSE SELECT workspace_id INTO workspace FROM oracle2.meeting_final_mappings_v1 WHERE mapping_id=NEW.mapping_id;END IF;
 PERFORM pg_advisory_xact_lock(hashtext('oracle2-authz:'||workspace::text));RETURN NEW;
END $f$;
REVOKE ALL ON FUNCTION oracle2._meeting_final_mapping_lock_v1() FROM PUBLIC;
CREATE TRIGGER meeting_final_mapping_install_lock BEFORE INSERT ON oracle2.meeting_final_mappings_v1 FOR EACH ROW EXECUTE FUNCTION oracle2._meeting_final_mapping_lock_v1();
CREATE TRIGGER meeting_final_mapping_revoke_lock BEFORE INSERT ON oracle2.meeting_final_mapping_revocations_v1 FOR EACH ROW EXECUTE FUNCTION oracle2._meeting_final_mapping_lock_v1();

-- Worker rows below are delivery custody for EXISTING capture business intents.
-- NULL legacy admissions retain their old APIs and grant no new worker effect.
ALTER TABLE oracle2.meeting_capture_admissions_v1
 ADD COLUMN worker_id uuid, ADD COLUMN worker_effect text,
 ADD COLUMN worker_policy_sha256 text,ADD COLUMN worker_create_operation_id uuid,
 ADD COLUMN worker_create_request_sha256 text,ADD COLUMN worker_retrieve_stage text,
 ADD COLUMN worker_retrieve_operation_id uuid,
 ADD CONSTRAINT meeting_worker_exact_installation_v1 CHECK (
  (worker_id IS NULL AND worker_effect IS NULL AND worker_policy_sha256 IS NULL
   AND worker_create_operation_id IS NULL AND worker_create_request_sha256 IS NULL
   AND worker_retrieve_stage IS NULL AND worker_retrieve_operation_id IS NULL)
  OR (worker_id IS NOT NULL AND worker_effect IS NOT NULL AND worker_effect IN('capture-create','capture-leave','capture-retrieve')
   AND worker_policy_sha256 IS NOT NULL AND worker_policy_sha256~'^[a-f0-9]{64}$'
   AND ((worker_effect='capture-create' AND worker_create_operation_id IS NOT NULL
    AND worker_create_request_sha256 IS NOT NULL AND worker_create_request_sha256~'^[a-f0-9]{64}$')
    OR (worker_effect<>'capture-create' AND worker_create_operation_id IS NULL AND worker_create_request_sha256 IS NULL))
   AND ((worker_effect='capture-retrieve' AND worker_retrieve_stage IS NOT NULL AND worker_retrieve_stage IN('pre-stop-consistency','post-stop-terminal') AND worker_retrieve_operation_id IS NOT NULL)
    OR (worker_effect<>'capture-retrieve' AND worker_retrieve_stage IS NULL AND worker_retrieve_operation_id IS NULL))));
CREATE TABLE oracle2.meeting_capture_worker_claims_v1 (
 claim_id uuid PRIMARY KEY,workspace_id uuid NOT NULL,meeting_id uuid NOT NULL,
 intent_event_id uuid NOT NULL REFERENCES oracle2.meeting_capture_events_v1(event_id),
 effect text NOT NULL CHECK(effect IN('capture-create','capture-leave','capture-retrieve')),
 stage text NOT NULL CHECK(stage IN('-','pre-stop-consistency','post-stop-terminal')),
 admission_id uuid NOT NULL REFERENCES oracle2.meeting_capture_admissions_v1(admission_id),worker_id uuid NOT NULL,
 operation_id uuid NOT NULL,request_sha256 text NOT NULL CHECK(request_sha256~'^[a-f0-9]{64}$'),bot_id uuid,
 original_deadline timestamptz NOT NULL CHECK(isfinite(original_deadline)),created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 CHECK((effect='capture-create')=(bot_id IS NULL)),CHECK((effect='capture-retrieve')=(stage<>'-')),
 UNIQUE(workspace_id,meeting_id,intent_event_id,effect,stage));
CREATE TABLE oracle2.meeting_capture_worker_receipts_v1 (
 receipt_id uuid PRIMARY KEY,claim_id uuid NOT NULL UNIQUE REFERENCES oracle2.meeting_capture_worker_claims_v1(claim_id),
 admission_id uuid NOT NULL REFERENCES oracle2.meeting_capture_admissions_v1(admission_id),worker_id uuid NOT NULL,
 wire_object_key text NOT NULL,wire_sha256 text NOT NULL CHECK(wire_sha256~'^[a-f0-9]{64}$'),
 wire_byte_count integer NOT NULL CHECK(wire_byte_count BETWEEN 0 AND 1064960),
 observation jsonb NOT NULL CHECK(jsonb_typeof(observation)='object' AND octet_length(observation::text)<=16384),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp());
REVOKE ALL ON oracle2.meeting_capture_worker_claims_v1,oracle2.meeting_capture_worker_receipts_v1 FROM PUBLIC,oracle2_replacement_requester;
CREATE TRIGGER immutable_meeting_capture_worker_claims_v1 BEFORE UPDATE OR DELETE ON oracle2.meeting_capture_worker_claims_v1
 FOR EACH ROW EXECUTE FUNCTION oracle2.deny_operating_model_mutation();
CREATE TRIGGER immutable_meeting_capture_worker_receipts_v1 BEFORE UPDATE OR DELETE ON oracle2.meeting_capture_worker_receipts_v1
 FOR EACH ROW EXECUTE FUNCTION oracle2.deny_operating_model_mutation();

-- Fixed delivery API: no caller-selected effect, stage, worker, body or grant.
CREATE FUNCTION oracle2.meeting_capture_worker_v1(selected uuid,seal text,command text,
 wanted_operation uuid,wanted_claim uuid,body_sha256 text,wire jsonb,deadline timestamptz)
 RETURNS jsonb LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog,oracle2 AS $f$
DECLARE m oracle2.meeting_capture_admissions_v1%ROWTYPE;h oracle2.meeting_capture_heads_v1%ROWTYPE;
 intent oracle2.meeting_capture_events_v1%ROWTYPE;proof oracle2.meeting_capture_events_v1%ROWTYPE;
 supervisor oracle2.meeting_capture_admissions_v1%ROWTYPE;claimed oracle2.meeting_capture_worker_claims_v1%ROWTYPE;
 received oracle2.meeting_capture_worker_receipts_v1%ROWTYPE;act text;delivery_stage text;op uuid;bot uuid;hash text;
 state text:='idle';fresh boolean:=false;until timestamptz;expected_key text;
BEGIN
 IF command IS NULL OR command NOT IN('prepare','claim','current','observe','status')
 OR (command<>'observe' AND wire IS NOT NULL) OR (command='prepare' AND (wanted_operation IS NOT NULL OR wanted_claim IS NOT NULL))
 OR (command IN('current','observe') AND (wanted_operation IS NULL OR wanted_claim IS NULL))
 OR (command='claim' AND (wanted_operation IS NULL OR wanted_claim IS NOT NULL)) THEN
  RAISE EXCEPTION 'fixed closed worker operation required';END IF;
 SELECT * INTO m FROM oracle2.meeting_capture_admissions_v1 WHERE admission_id=selected;
 IF m.worker_id IS NULL OR m.worker_effect IS NULL OR m.worker_policy_sha256 IS NULL THEN
  RAISE insufficient_privilege USING MESSAGE='independently installed worker admission required';END IF;
 act:=CASE WHEN command='status' THEN 'status' WHEN m.worker_effect='capture-create' AND command='observe' THEN 'create_observed'
  WHEN m.worker_effect='capture-create' THEN 'create_intent' WHEN m.worker_effect='capture-leave' AND command='observe' THEN 'stop_observed'
  WHEN m.worker_effect='capture-leave' THEN 'stop_intent' ELSE 'stop_reconciled' END;
 m:=oracle2._meeting_capture_admission_v1(selected,seal,act,deadline);
 IF m.provider<>'recall' OR m.worker_effect NOT IN('capture-create','capture-leave','capture-retrieve') THEN
  RAISE insufficient_privilege USING MESSAGE='exact installed Recall worker required';END IF;
 delivery_stage:=coalesce(m.worker_retrieve_stage,'-');
 PERFORM pg_advisory_xact_lock(hashtext('oracle2-meeting:'||m.workspace_id::text||':'||m.meeting_id::text));
 SELECT * INTO h FROM oracle2.meeting_capture_heads_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id FOR UPDATE;
 IF h.meeting_id IS NULL THEN RAISE insufficient_privilege USING MESSAGE='existing invitation required';END IF;
 SELECT * INTO intent FROM oracle2.meeting_capture_events_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id
  AND operation_id=CASE WHEN m.worker_effect='capture-leave' THEN h.stop_intent_id ELSE h.create_intent_id END
  AND action=CASE WHEN m.worker_effect='capture-leave' THEN 'stop_intent' ELSE 'create_intent' END FOR SHARE;
 IF intent.event_id IS NULL AND command='prepare' AND m.worker_effect='capture-create' THEN
  SELECT * INTO proof FROM oracle2.meeting_capture_events_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id
   AND admission_id=m.supervisor_admission_id AND action='supervised'
   AND payload->>'create_operation_id'=m.worker_create_operation_id::text
   AND payload->>'request_sha256'=m.worker_create_request_sha256 ORDER BY version DESC LIMIT 1 FOR SHARE;
  IF proof.event_id IS NULL THEN RAISE insufficient_privilege USING MESSAGE='actual independent supervisor receipt required before prepare';END IF;
  PERFORM oracle2.meeting_capture_transition_v1(selected,seal,h.version,m.worker_create_operation_id,'create_intent',
   jsonb_build_object('request_sha256',m.worker_create_request_sha256,'supervisor_event_id',proof.event_id,
    'supervisor_event_sha256',proof.payload_sha256,'supervisor_witness_sha256',proof.payload->>'witness_sha256'),deadline);
  SELECT * INTO h FROM oracle2.meeting_capture_heads_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id FOR UPDATE;
  SELECT * INTO intent FROM oracle2.meeting_capture_events_v1 WHERE event_id=h.create_intent_id AND action='create_intent'
   AND workspace_id=m.workspace_id AND meeting_id=m.meeting_id FOR SHARE;
 END IF;
 IF intent.event_id IS NULL THEN RAISE insufficient_privilege USING MESSAGE='existing business intent required before delivery';END IF;
 op:=CASE WHEN m.worker_effect='capture-create' THEN m.worker_create_operation_id
  WHEN m.worker_effect='capture-retrieve' THEN m.worker_retrieve_operation_id ELSE intent.operation_id END;
 hash:=CASE WHEN m.worker_effect='capture-create' THEN m.worker_create_request_sha256 ELSE encode(sha256(''::bytea),'hex') END;
 IF op IS NULL OR hash IS NULL OR (body_sha256 IS NOT NULL AND body_sha256 IS DISTINCT FROM hash)
 OR (wanted_operation IS NOT NULL AND wanted_operation IS DISTINCT FROM op) THEN RAISE EXCEPTION 'exact immutable operation and body required';END IF;
 IF m.worker_effect='capture-create' THEN
  IF intent.operation_id IS DISTINCT FROM op OR intent.payload->>'request_sha256' IS DISTINCT FROM hash THEN
   RAISE insufficient_privilege USING MESSAGE='installed create binding differs';END IF;
 ELSE
  SELECT * INTO proof FROM oracle2.meeting_capture_events_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id
   AND action='create_observed' AND payload->>'intent_id'=h.create_intent_id::text ORDER BY version DESC LIMIT 1 FOR SHARE;
  IF proof.event_id IS NULL OR proof.payload->>'bot_id' IS DISTINCT FROM m.bot_id OR m.stop_mapping_sha256 IS NULL
   OR m.bot_id !~ '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$' THEN
   RAISE insufficient_privilege USING MESSAGE='exact independently mapped created bot required';END IF;
  bot:=m.bot_id::uuid;
 END IF;
 SELECT * INTO claimed FROM oracle2.meeting_capture_worker_claims_v1 WHERE workspace_id=m.workspace_id AND meeting_id=m.meeting_id
  AND intent_event_id=intent.event_id AND effect=m.worker_effect AND meeting_capture_worker_claims_v1.stage=delivery_stage;
 IF claimed.claim_id IS NOT NULL THEN
  -- No newly admitted generation can reset or inherit execution authority.
  IF claimed.operation_id IS DISTINCT FROM op OR claimed.request_sha256 IS DISTINCT FROM hash OR claimed.bot_id IS DISTINCT FROM bot THEN
   RAISE EXCEPTION 'retained delivery binding collision';END IF;
  SELECT * INTO received FROM oracle2.meeting_capture_worker_receipts_v1 WHERE claim_id=claimed.claim_id;
  state:=CASE WHEN received.receipt_id IS NOT NULL AND received.observation->>'kind' IN('create-observed','leave-observed','metadata-observed') THEN 'observed' ELSE 'UNKNOWN' END;
 END IF;
 IF command IN('claim','current') THEN
  IF h.state IN('UNKNOWN','cancelled') AND m.worker_effect='capture-create' THEN RAISE insufficient_privilege USING MESSAGE='closed capture cannot create';END IF;
  IF m.worker_effect='capture-create' THEN
   SELECT * INTO proof FROM oracle2.meeting_capture_events_v1 WHERE event_id=(intent.payload->>'supervisor_event_id')::uuid
    AND workspace_id=m.workspace_id AND meeting_id=m.meeting_id AND action='supervised' FOR SHARE;
   SELECT * INTO supervisor FROM oracle2.meeting_capture_admissions_v1 WHERE admission_id=m.supervisor_admission_id FOR SHARE;
   IF proof.event_id IS NULL OR supervisor.admission_id IS NULL OR supervisor.principal_id=m.principal_id OR proof.admission_id IS DISTINCT FROM supervisor.admission_id
    OR proof.actor_id IS DISTINCT FROM supervisor.principal_id OR proof.payload_sha256 IS DISTINCT FROM intent.payload->>'supervisor_event_sha256'
    OR proof.payload->>'witness_sha256' IS DISTINCT FROM intent.payload->>'supervisor_witness_sha256'
    OR proof.payload->>'request_sha256' IS DISTINCT FROM hash OR proof.payload->>'create_operation_id' IS DISTINCT FROM op::text
    OR proof.payload->>'scope_sha256' IS DISTINCT FROM m.supervision_scope_sha256 OR supervisor.supervision_scope_sha256 IS DISTINCT FROM m.supervision_scope_sha256
    OR supervisor.capture_until IS DISTINCT FROM m.capture_until OR supervisor.valid_from>clock_timestamp() OR supervisor.expires_at<=clock_timestamp()
    OR (proof.payload->>'valid_until')::timestamptz<=clock_timestamp() OR m.capture_until<=clock_timestamp()
    OR EXISTS(SELECT 1 FROM oracle2.meeting_capture_revocations_v1 WHERE admission_id=supervisor.admission_id) THEN
    RAISE insufficient_privilege USING MESSAGE='fresh independent actual supervisor required before effect';END IF;
   IF NOT EXISTS(SELECT 1 FROM oracle2.hosting_request_principal_admissions a JOIN oracle2.hosting_role_runtime_admissions r USING(role_name)
    JOIN pg_roles role ON role.rolname=a.role_name WHERE a.role_name=supervisor.role_name AND a.principal_id=supervisor.principal_id
    AND a.workspace_id=m.workspace_id AND a.runtime_hash=supervisor.runtime_hash AND a.registry_hash=supervisor.registry_hash
    AND r.runtime_hash=a.runtime_hash AND r.registry_hash=a.registry_hash AND a.expires_at>clock_timestamp() AND r.expires_at>clock_timestamp()
    AND isfinite(r.expires_at) AND role.rolcanlogin AND NOT(role.rolsuper OR role.rolcreatedb OR role.rolcreaterole OR role.rolreplication OR role.rolbypassrls)) THEN
    RAISE insufficient_privilege USING MESSAGE='current independent supervisor process role required';END IF;
   PERFORM oracle2._meeting_capture_lineage_v1(supervisor);
  ELSIF m.worker_effect='capture-leave' AND h.stop_state<>'inflight' THEN RAISE insufficient_privilege USING MESSAGE='current exact STOP intent required';
  ELSIF m.worker_effect='capture-retrieve' THEN
   IF (delivery_stage='pre-stop-consistency' AND h.stop_intent_id IS NOT NULL)
    OR (delivery_stage='post-stop-terminal' AND h.stop_intent_id IS NULL) THEN RAISE insufficient_privilege USING MESSAGE='fixed retrieval stage differs from current STOP';END IF;
  END IF;
 END IF;
 IF command='claim' AND claimed.claim_id IS NULL THEN
  IF body_sha256 IS DISTINCT FROM hash THEN RAISE EXCEPTION 'actual independently pinned body must be checked before claim';END IF;
  INSERT INTO oracle2.meeting_capture_worker_claims_v1(claim_id,workspace_id,meeting_id,intent_event_id,effect,stage,admission_id,worker_id,operation_id,request_sha256,bot_id,original_deadline)
   VALUES(gen_random_uuid(),m.workspace_id,m.meeting_id,intent.event_id,m.worker_effect,delivery_stage,selected,m.worker_id,op,hash,bot,least(m.expires_at,deadline)) RETURNING * INTO claimed;
  state:='claimed';fresh:=true;
 ELSIF command='prepare' AND claimed.claim_id IS NULL THEN state:='prepared';
 ELSIF command IN('current','observe') THEN
  IF claimed.claim_id IS NULL OR claimed.claim_id IS DISTINCT FROM wanted_claim OR claimed.admission_id<>selected OR claimed.worker_id<>m.worker_id
   OR claimed.original_deadline<=clock_timestamp() OR deadline>claimed.original_deadline THEN RAISE insufficient_privilege USING MESSAGE='current exact own claimed delivery required';END IF;
  IF command='current' THEN
   IF received.receipt_id IS NOT NULL THEN RAISE insufficient_privilege USING MESSAGE='observed delivery cannot execute again';END IF;
   state:='inflight';
  ELSE
   IF jsonb_typeof(wire) IS DISTINCT FROM 'object' OR NOT(wire?&ARRAY['wire_object_key','wire_sha256','wire_byte_count','observation'])
    OR wire-ARRAY['wire_object_key','wire_sha256','wire_byte_count','observation']<>'{}'::jsonb
    OR jsonb_typeof(wire->'wire_sha256') IS DISTINCT FROM 'string' OR wire->>'wire_sha256' !~ '^[a-f0-9]{64}$'
    OR jsonb_typeof(wire->'wire_byte_count') IS DISTINCT FROM 'number' OR wire->>'wire_byte_count' !~ '^(0|[1-9][0-9]{0,6})$'
    OR (wire->>'wire_byte_count')::integer>1064960 OR jsonb_typeof(wire->'observation') IS DISTINCT FROM 'object'
    OR NOT((wire->'observation')?&ARRAY['kind','bot_id','latest_status','complete'])
    OR (wire->'observation')-ARRAY['kind','bot_id','latest_status','complete']<>'{}'::jsonb
    OR jsonb_typeof(wire->'observation'->'kind') IS DISTINCT FROM 'string'
    OR wire->'observation'->>'kind' NOT IN('create-observed','leave-observed','metadata-observed','UNKNOWN')
    OR jsonb_typeof(wire->'observation'->'complete') IS DISTINCT FROM 'boolean'
    OR (wire->'observation'->>'kind'<>'UNKNOWN' AND wire->'observation'->'complete'<>'true'::jsonb) THEN
    RAISE EXCEPTION 'exact retained bounded response custody required';END IF;
   expected_key:='meeting-worker/'||m.workspace_id::text||'/'||m.meeting_id::text||'/'||claimed.claim_id::text||'/'||(wire->>'wire_sha256')||'.wire';
   IF wire->>'wire_object_key' IS DISTINCT FROM expected_key THEN RAISE EXCEPTION 'exact own immutable wire key required';END IF;
   IF received.receipt_id IS NULL THEN
    INSERT INTO oracle2.meeting_capture_worker_receipts_v1(receipt_id,claim_id,admission_id,worker_id,wire_object_key,wire_sha256,wire_byte_count,observation)
     VALUES(gen_random_uuid(),claimed.claim_id,selected,m.worker_id,expected_key,wire->>'wire_sha256',(wire->>'wire_byte_count')::integer,wire->'observation') RETURNING * INTO received;
   ELSIF received.wire_object_key IS DISTINCT FROM expected_key OR received.wire_sha256 IS DISTINCT FROM wire->>'wire_sha256'
    OR received.wire_byte_count IS DISTINCT FROM (wire->>'wire_byte_count')::integer OR received.observation IS DISTINCT FROM wire->'observation' THEN
    RAISE EXCEPTION 'immutable delivery receipt collision';END IF;
   state:=CASE WHEN received.observation->>'kind'='UNKNOWN' THEN 'UNKNOWN' ELSE 'observed' END;
  END IF;
 END IF;
 until:=least(m.expires_at,deadline,CASE WHEN command='status' THEN deadline ELSE coalesce(claimed.original_deadline,deadline) END);
 RETURN jsonb_build_object('meeting_id',m.meeting_id,'capture_until',m.capture_until,'valid_until',until,
  'context',oracle2._replacement_private_context(oracle2._replacement_request_context(),until),'state',state,'fresh_claim',fresh,
  'worker_id',m.worker_id,'stop_mapping_sha256',m.stop_mapping_sha256,'operation_policy_sha256',m.worker_policy_sha256,'effect',m.worker_effect,'stage',delivery_stage,'operation_id',op,'intent_event_id',intent.event_id,
  'claim_id',claimed.claim_id,'claim_admission_id',claimed.admission_id,'claim_worker_id',claimed.worker_id,'claim_original_deadline',claimed.original_deadline,'request_sha256',hash,'bot_id',bot,'receipt_id',received.receipt_id,'observation',received.observation);
END $f$;
REVOKE ALL ON FUNCTION oracle2.meeting_capture_worker_v1(uuid,text,text,uuid,uuid,text,jsonb,timestamptz) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION oracle2.meeting_capture_worker_v1(uuid,text,text,uuid,uuid,text,jsonb,timestamptz) TO oracle2_replacement_requester;
