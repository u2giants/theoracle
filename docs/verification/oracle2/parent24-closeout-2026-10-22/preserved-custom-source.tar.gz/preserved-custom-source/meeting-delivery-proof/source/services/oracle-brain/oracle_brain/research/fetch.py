"""Guarded fetch: rejects private/link-local destinations and unsafe redirects. Transport is injected."""
from dataclasses import dataclass
import socket
from typing import Callable
from urllib.parse import urljoin, urlsplit
from .rights import RightsError, require_public_addresses

MAX_REDIRECTS = 5


class UnsafeDestination(ValueError):
    pass


@dataclass(frozen=True)
class Response:
    status: int
    body: bytes = b''
    location: str | None = None


Resolver = Callable[[str], list[str]]
Transport = Callable[[str, str], Response]  # (url, pinned_ip) -> Response


def system_resolver(host: str) -> list[str]:
    return [info[4][0] for info in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)]


def check_destination(url: str, resolver: Resolver) -> str:
    try:
        if type(url) is not str or any(ord(c) <= 32 or ord(c) == 127 for c in url):
            raise ValueError('invalid destination')
        parts = urlsplit(url)
        if (parts.scheme != 'https' or not parts.hostname or parts.username
                or parts.password or parts.port not in (None, 443)):
            raise ValueError('invalid destination')
    except ValueError:
        raise UnsafeDestination('refused HTTPS destination') from None
    try:
        return require_public_addresses(resolver(parts.hostname))
    except RightsError as error:
        raise UnsafeDestination(str(error)) from None


def guarded_fetch(url: str, transport: Transport, resolver: Resolver = system_resolver) -> Response:
    """Every hop is re-validated; the transport must connect to the pinned address (no re-resolution)."""
    for _ in range(MAX_REDIRECTS + 1):
        pinned = check_destination(url, resolver)
        response = transport(url, pinned)
        if response.status in (301, 302, 303, 307, 308):
            if not response.location:
                raise UnsafeDestination('redirect without location')
            url = urljoin(url, response.location)
            continue
        return response
    raise UnsafeDestination('too many redirects')

# Private fixed installed-artifact owner. The general research helper above
# retains its original API; no arbitrary URL/key/redirect selector is added.
class _InstalledArtifactGET:
    def __init__(self,*,url,expected_sha256,byte_count,ca_file,ca_sha256,server_der_sha256,current):
        import re,ssl,hashlib
        from pathlib import Path
        from oracle_brain.hosting.original_intake_v1 import _pinned
        from oracle_brain.hosting.purpose_transport import _BoundedDNSResolver
        if not callable(current) or type(byte_count) is not int or not 0<byte_count<=1024*1024 or any(type(v) is not str or re.fullmatch('[a-f0-9]{64}',v) is None for v in (expected_sha256,ca_sha256,server_der_sha256)):raise UnsafeDestination('fixed artifact pins required')
        parts=urlsplit(url)
        if parts.scheme!='https' or not parts.hostname or parts.username or parts.password or parts.fragment or parts.port not in (None,443) or not parts.path.startswith('/') or any(ord(c)<=32 or ord(c)==127 for c in url):raise UnsafeDestination('exact installed HTTPS artifact required')
        if not Path(ca_file).is_absolute():raise UnsafeDestination('fixed artifact CA required')
        self.url=url;self.parts=parts;self.expected_sha256=expected_sha256;self.byte_count=byte_count;self.ca_file=ca_file;self.ca_sha256=ca_sha256;self.server_der_sha256=server_der_sha256;self.current=current
        self._resolver=_BoundedDNSResolver(parts.hostname,443)
        self._tls=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT);self._tls.minimum_version=ssl.TLSVersion.TLSv1_2
        self._tls.load_verify_locations(cadata=_pinned(ca_file,ca_sha256,131072).decode('utf-8'))
    def fetch(self,*,caller_deadline):
        import http.client,socket,threading,time,hashlib
        from datetime import datetime,timezone
        from oracle_brain.hosting.original_intake_v1 import _pinned
        from oracle_brain.research.rights import require_public_addresses
        from oracle_brain.hosting._protected_control_listener_v1 import request_remaining_v1
        original_remaining=request_remaining_v1(required=True)
        now=datetime.now(timezone.utc)
        if type(caller_deadline) is not datetime or caller_deadline.tzinfo is None or not 0<(caller_deadline-now).total_seconds()<=30:raise UnsafeDestination('original artifact deadline required')
        end=time.monotonic()+min(original_remaining,(caller_deadline-now).total_seconds())
        def remaining():
            request_remaining_v1(required=True)
            self.current()
            if hashlib.sha256(_pinned(self.ca_file,self.ca_sha256,131072)).hexdigest()!=self.ca_sha256:raise UnsafeDestination('artifact CA changed')
            value=min(request_remaining_v1(required=True),end-time.monotonic(),(caller_deadline-datetime.now(timezone.utc)).total_seconds())
            if value<=0:raise UnsafeDestination('artifact original horizon elapsed')
            return value
        remaining();addresses=self._resolver.resolve(end)
        # ALL answers must be public unicast, not only the chosen answer. No
        # re-resolution, fallback target, retry, proxy, auth header or redirects.
        require_public_addresses([row[4][0] for row in addresses])
        family,kind,protocol,_,target=addresses[0]
        if family not in (socket.AF_INET,socket.AF_INET6) or kind!=socket.SOCK_STREAM or target[1]!=443:raise UnsafeDestination('artifact DNS answer differs')
        active=socket.socket(family,kind,protocol);conn=None;timer=None
        try:
            active.settimeout(remaining());active.connect(target)
            active.settimeout(remaining());secure=self._tls.wrap_socket(active,server_hostname=self.parts.hostname,suppress_ragged_eofs=False);active=secure
            if hashlib.sha256(secure.getpeercert(binary_form=True)).hexdigest()!=self.server_der_sha256:raise UnsafeDestination('artifact TLS DER differs')
            return _read_artifact_http_v1(secure,self.parts.hostname,self.parts.path+('?' + self.parts.query if self.parts.query else ''),self.expected_sha256,self.byte_count,remaining)
        finally:
            if timer:timer.cancel()
            if conn:conn.close()
            active.close()


def _artifact_response_v1(secure,remaining,maximum,**kwargs):
    """One unbuffered view of the verified socket; HTTPResponse parses semantics.

    No header read may prefetch and silently discard undeclared extra plaintext.
    A bounded prefix tracks only the first exact header end and wire byte count.
    """
    import http.client,io
    class Wire(io.RawIOBase):
        def __init__(self):self.prefix=bytearray();self.header_length=None;self.count=0
        def readable(self):return True
        def readinto(self,buffer):
            secure.settimeout(remaining());data=secure.recv(len(buffer))
            self.count+=len(data)
            if self.header_length is None:
                self.prefix.extend(data)
                end=self.prefix.find(b'\r\n\r\n')
                if end>=0:self.header_length=end+4;self.prefix.clear()
                elif len(self.prefix)>16384:raise UnsafeDestination('artifact header exceeds limit')
            if self.count>16384+maximum or (self.header_length is not None and self.count>self.header_length+maximum):raise UnsafeDestination('extra artifact wire bytes')
            buffer[:len(data)]=data;return len(data)
    wire=Wire()
    class View:
        def makefile(self,*_args,**_kwargs):return wire
    return http.client.HTTPResponse(View(),**kwargs)

def _read_artifact_http_v1(secure,hostname,path,expected_sha256,byte_count,remaining):
    import http.client,socket,threading,hashlib
    conn=None;timer=None
    try:
        # Per-request ownership: HTTP may release its reference, while this
        # owner retains the SAME verified socket for actual final EOF.
        class Connection(http.client.HTTPSConnection):
            def close(connection):
                connection.sock=None
                super().close()
        conn=Connection(hostname,443,timeout=remaining(),context=None);conn.sock=secure
        conn.response_class=lambda sock,**kw:_artifact_response_v1(sock,remaining,byte_count,**kw)
        def stop():
            try:secure.shutdown(socket.SHUT_RDWR)
            except OSError:pass
        timer=threading.Timer(remaining(),stop);timer.daemon=True;timer.start();remaining()
        conn.request('GET',path,headers={'Accept':'application/json, text/vtt','Connection':'close'})
        response=conn.getresponse();headers=response.getheaders();seen=set()
        for key,value in headers:
            key=key.lower()
            if key in seen:raise UnsafeDestination('duplicate artifact header')
            seen.add(key)
        lengths=response.headers.get_all('Content-Length',[])
        if response.status!=200 or response.headers.get('Content-Encoding') is not None or response.headers.get('Transfer-Encoding') is not None or len(lengths)!=1 or lengths[0]!=str(byte_count):raise UnsafeDestination('exact nonredirect artifact length required')
        result=bytearray()
        while len(result)<byte_count:
            secure.settimeout(remaining());chunk=response.read(min(65536,byte_count-len(result)))
            if not chunk:raise UnsafeDestination('truncated artifact')
            result.extend(chunk)
        if not response.isclosed():response.close()
        # Read exact final transport EOF, refusing undeclared/delayed bytes.
        secure.settimeout(remaining())
        if secure.recv(1):raise UnsafeDestination('extra artifact bytes')
        remaining();raw=bytes(result)
        if hashlib.sha256(raw).hexdigest()!=expected_sha256:raise UnsafeDestination('artifact original hash differs')
        return raw
    finally:
        if timer:timer.cancel()
        if conn:conn.close()
