'use client';

import {useEffect,useState} from 'react';

type HostState=Readonly<{meeting_id:string;head_revision:number;generation:number;host_enabled:boolean;
 proactive_enabled:boolean;proactive_count:number;visible_message_proven:false;remote_stop_proven:false;
 executable:false;valid_until:string}>;
const fields=['meeting_id','head_revision','generation','host_enabled','proactive_enabled','proactive_count',
 'visible_message_proven','remote_stop_proven','executable','valid_until'];
function metadata(value:unknown):HostState{
 if(!value||typeof value!=='object'||Array.isArray(value))throw new Error();
 const v=value as Record<string,unknown>;
 if(Object.keys(v).length!==fields.length||fields.some(k=>!Object.hasOwn(v,k))
  ||typeof v.meeting_id!=='string'||!(/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/).test(v.meeting_id)
  ||['head_revision','generation','proactive_count'].some(k=>!Number.isSafeInteger(v[k])||(v[k]as number)<0)
  ||(v.proactive_count as number)>3||typeof v.host_enabled!=='boolean'||typeof v.proactive_enabled!=='boolean'
  ||v.visible_message_proven!==false||v.remote_stop_proven!==false||v.executable!==false
  ||typeof v.valid_until!=='string'||!Number.isFinite(Date.parse(v.valid_until))||Date.parse(v.valid_until)<=Date.now())throw new Error();
 return v as unknown as HostState;
}

/** Host control only. No chat text, recipient, bot, role or observation input. */
export function MeetingParticipationControls(){
 const [current,setCurrent]=useState<HostState>();
 const [proactive,setProactive]=useState(false);
 const [busy,setBusy]=useState(false);
 const [notice,setNotice]=useState('Load current meeting controls before making a change.');
 useEffect(()=>{
  if(!current)return;
  const timer=setTimeout(()=>{setCurrent(undefined);setProactive(false);
   setNotice('The current control window ended. Reload before making another change.');},Math.max(0,Date.parse(current.valid_until)-Date.now()));
  return()=>clearTimeout(timer);
 },[current]);
 async function request(enabled?:boolean){
  if(busy||enabled!==undefined&&!current)return;
  setBusy(true);
  try{
   const command=enabled===undefined?{operation:'status'}:{operation:'control',expected_head:current!.head_revision,
    command_id:crypto.randomUUID(),enabled,proactive_enabled:enabled&&proactive,cooldown_seconds:120,max_proactive:3};
   const response=await fetch('/api/consultant/meetings/participation',{method:'POST',credentials:'same-origin',
    headers:{'Content-Type':'application/json'},body:JSON.stringify(command),cache:'no-store'});
   if(!response.ok)throw new Error();
   const fresh=metadata(await response.json());setCurrent(fresh);setProactive(fresh.proactive_enabled);
   setNotice(enabled===false?'Participation disabled. This does not stop meeting capture.':
    enabled===true?'Host permission recorded. Sending still requires current meeting permission.':
    'Current host controls loaded. Sending stays off when meeting permission cannot be verified.');
  }catch{
   setCurrent(undefined);setProactive(false);
   setNotice('The outcome is unavailable. Reload the current controls before another change. No message is repeated.');
  }finally{setBusy(false);}
 }
 return <section aria-labelledby="participation-title" className="space-y-5 rounded-xl border p-6">
  <h1 id="participation-title" className="text-xl font-semibold">Meeting participation</h1>
  <p>Oracle can quote or ask about the current meeting turn. These controls do not approve company rules.</p>
  <p role="status" aria-live="polite">{notice}</p>
  {current&&<p>{current.host_enabled?'Host permission is on.':'Host permission is off.'} Proactive attempts used: {current.proactive_count} of 3.</p>}
  <label className="flex items-center gap-3"><input type="checkbox" checked={proactive}
   disabled={busy||!current} onChange={event=>setProactive(event.target.checked)}/>
   Allow up to three proactive clarifications, at least two minutes apart</label>
  <div className="flex flex-wrap gap-3">
   <button type="button" disabled={busy} onClick={()=>void request()}
    className="rounded-md border px-4 py-2 disabled:cursor-not-allowed disabled:opacity-40">Reload controls</button>
   <button type="button" disabled={busy||!current} onClick={()=>void request(true)}
    className="rounded-md bg-blue-700 px-4 py-2 text-white disabled:cursor-not-allowed disabled:bg-slate-300 disabled:text-slate-600">Enable participation</button>
   <button type="button" disabled={busy||!current||!current.host_enabled} onClick={()=>void request(false)}
    className="rounded-md border border-red-700 px-4 py-2 text-red-800 disabled:cursor-not-allowed disabled:border-slate-300 disabled:text-slate-400">Disable participation</button>
  </div>
  <p className="text-sm text-slate-600">A provider response does not prove a message was visible. Disabling participation does not prove remote activity stopped.</p>
 </section>;
}
