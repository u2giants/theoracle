import {requireEmployee} from '@/lib/auth-guard';
import {MeetingParticipationControls} from './participation-controls';

export default async function MeetingParticipationPage(){
 await requireEmployee();
 return <main className="mx-auto max-w-3xl p-6"><MeetingParticipationControls /></main>;
}
