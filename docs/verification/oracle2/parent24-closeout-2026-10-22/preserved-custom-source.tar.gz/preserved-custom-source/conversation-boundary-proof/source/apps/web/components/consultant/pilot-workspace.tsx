'use client';

// Pilot workspace: upload → draft → correct → confirm → ask → cited answer.
import { useCallback, useEffect, useState } from 'react';
import { useSessionValue } from '@/lib/use-session-value';

interface Block {
  blockId: string;
  blockIndex: number;
  text: string;
  spanStart: number;
  spanEnd: number;
}

interface Citation {
  sourceId: string;
  spanStart: number;
  spanEnd: number;
  quote: string;
}

interface Hypothetical {
  label: string;
  description: string;
  measure: string;
  missingInputs: string[];
}

interface Answer {
  answerText: string;
  citations: Citation[];
  hypothetical: Hypothetical | null;
  isEstablishedFact: boolean;
  holistic?: { source_count: number; distinct_original_count?: number; pipeline: string };
  evidenceStatus?: string;
  evidenceGraph?: { engine: string; corpus_source_count: number; cited_source_count: number };
}

interface RunData {
  runId: string;
  answer: Answer | null;
  status: string;
}

function jsonHeaders(): Record<string, string> {
  return { 'Content-Type': 'application/json' };
}

export function PilotWorkspace() {
  const [text, setText] = useState('');
  const savedSourceId = useSessionValue('oracle2-source-id');
  const savedDraftId = useSessionValue('oracle2-draft-id');
  const savedRunId = useSessionValue('oracle2-run-id');
  const [chosenSourceId, setSourceId] = useState<string | null | undefined>(undefined);
  const sourceId = chosenSourceId === undefined ? savedSourceId : chosenSourceId;
  const [chosenDraftId, setDraftId] = useState<string | null | undefined>(undefined);
  const draftId = chosenDraftId === undefined ? savedDraftId : chosenDraftId;
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [connections, setConnections] = useState<Array<{ from: number; to: number }>>([]);
  const [status, setStatus] = useState<string>('');
  const [confirmed, setConfirmed] = useState(false);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState<Answer | null>(null);
  const [chosenRunId, setRunId] = useState<string | null | undefined>(undefined);
  const runId = chosenRunId === undefined ? savedRunId : chosenRunId;
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [pilotTokenInput, setPilotTokenInput] = useState('');
  const [actorId, setActorId] = useState<string | null>(null);

  // Persist run/source so the answer survives a page refresh.
  useEffect(() => {
    if (runId) {
      const controller = new AbortController();
      fetch(`/api/consultant/runs/${encodeURIComponent(runId)}`, { credentials: 'same-origin', cache: 'no-store', signal: controller.signal })
        .then((r) => r.json())
        .then((data) => {
          if (data.status === 'pending' || data.status === 'processing') setStatus('processing');
          if (data.status === 'error' || data.status === 'cancelled') setError(data.error ?? 'Connected answer did not complete');
          if (data.answer) {
            setAnswer(data.answer);
            setConfirmed(true);
            setStatus('confirmed');
          }
        })
        .catch(() => {});
      return () => controller.abort();
    }
  }, [runId]);

  useEffect(() => {
    if (runId) sessionStorage.setItem('oracle2-run-id', runId);
    if (sourceId) sessionStorage.setItem('oracle2-source-id', sourceId);
    if (draftId) sessionStorage.setItem('oracle2-draft-id', draftId);
  }, [runId, sourceId, draftId]);

  useEffect(() => {
    if (!runId || status !== 'processing') return;
    const controller = new AbortController();
    const timer = setInterval(() => {
      fetch(`/api/consultant/runs/${runId}`, { credentials: 'same-origin', signal: controller.signal })
        .then(async (response) => {
          if (!response.ok) throw new Error('Could not retrieve the connected answer');
          return response.json();
        })
        .then((data) => {
          if (data.status === 'completed') {
            setAnswer(data.answer);
            setStatus('confirmed');
          } else if (data.status === 'error' || data.status === 'cancelled') {
            setError(data.error ?? 'Connected answer did not complete');
            setStatus('confirmed');
          }
        })
        .catch((error: Error) => {
          if (error.name !== 'AbortError') {
            setError('Could not retrieve the connected answer');
            setStatus('confirmed');
          }
        });
    }, 2000);
    return () => { clearInterval(timer); controller.abort(); };
  }, [runId, status]);

  const login = useCallback(async () => {
    setError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/consultant/session', {
        method: 'POST',
        headers: jsonHeaders(),
        body: JSON.stringify({ token: pilotTokenInput }),
        credentials: 'same-origin',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'login failed');
      setActorId(data.actorId);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'login failed');
    } finally {
      setLoading(false);
    }
  }, [pilotTokenInput]);

  const upload = useCallback(async () => {
    if (!actorId) return;
    setError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/consultant/sources', {
        method: 'POST',
        headers: jsonHeaders(),
        credentials: 'same-origin',
        body: JSON.stringify({ text, filename: 'pilot-process-table.txt', processName: 'Pilot process' }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'upload failed');
      setSourceId(data.sourceId);
      setDraftId(data.draftId);
      setBlocks(data.blocks);
      setStatus('draft');
      setConfirmed(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'upload failed');
    } finally {
      setLoading(false);
    }
  }, [text, actorId]);

  const correct = useCallback(async () => {
    if (!draftId) return;
    setError(null);
    setLoading(true);
    try {
      const res = await fetch(`/api/consultant/reviews/${draftId}`, {
        method: 'POST',
        headers: jsonHeaders(),
        credentials: 'same-origin',
        body: JSON.stringify({ action: 'correct', connections }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'correction failed');
      setStatus('draft (corrected)');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'correction failed');
    } finally {
      setLoading(false);
    }
  }, [draftId, connections]);

  const confirm = useCallback(async () => {
    if (!draftId) return;
    setError(null);
    setLoading(true);
    try {
      const res = await fetch(`/api/consultant/reviews/${draftId}`, {
        method: 'POST',
        headers: jsonHeaders(),
        credentials: 'same-origin',
        body: JSON.stringify({ action: 'confirm', scope: 'process-map' }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'confirmation failed');
      setConfirmed(true);
      setStatus('confirmed');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'confirmation failed');
    } finally {
      setLoading(false);
    }
  }, [draftId]);

  const ask = useCallback(async () => {
    if (!sourceId || !question.trim()) return;
    setError(null);
    setAnswer(null);
    setLoading(true);
    try {
      const res = await fetch('/api/consultant/questions', {
        method: 'POST',
        headers: jsonHeaders(),
        credentials: 'same-origin',
        body: JSON.stringify({ question, sourceId, draftId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'question failed');
      setAnswer(data.answer ?? null);
      setRunId(data.runId);
      if (data.status === 'pending') setStatus('processing');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'question failed');
    } finally {
      setLoading(false);
    }
  }, [sourceId, question, draftId]);

  const loadRun = useCallback(async () => {
    if (!runId) return;
    setError(null);
    try {
      const res = await fetch(`/api/consultant/runs/${runId}`, { credentials: 'same-origin' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'run not found');
      setAnswer(data.answer);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'load failed');
    }
  }, [runId]);

  return (
    <div data-testid="pilot-workspace" className="mx-auto max-w-3xl space-y-6 p-6">
      <h1 className="text-2xl font-bold">Oracle Pilot — Connected Document Understanding</h1>
      <p className="rounded border border-amber-300 bg-amber-50 p-3 text-sm">
        Pilot grading is paused until complete document coverage and connected understanding are verified.
        Earlier answers are historical and do not qualify for the corrected pilot.
      </p>

      {error && (
        <div data-testid="error-banner" className="rounded border border-red-400 bg-red-50 p-3 text-red-800">
          {error}
        </div>
      )}

      <section data-testid="pilot-login">
        <h2 className="mb-2 text-lg font-semibold">0. Pilot sign-in</h2>
        <input
          data-testid="pilot-token"
          type="password"
          className="w-full rounded border p-2"
          placeholder="Pilot token"
          value={pilotTokenInput}
          onChange={(e) => setPilotTokenInput(e.target.value)}
        />
        <button
          data-testid="pilot-login-btn"
          className="mt-2 rounded bg-slate-700 px-4 py-2 text-white disabled:opacity-50"
          onClick={login}
          disabled={loading}
        >
          Sign in
        </button>
        {actorId && (
          <p data-testid="pilot-actor" className="mt-1 text-sm text-gray-600">
            Signed in as {actorId}
          </p>
        )}
      </section>

      <section>
        <h2 className="mb-2 text-lg font-semibold">1. Upload a process document</h2>
        <textarea
          data-testid="document-text"
          className="h-32 w-full rounded border p-2"
          placeholder="Paste process table or document text…"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <button
          data-testid="upload-btn"
          className="mt-2 rounded bg-blue-600 px-4 py-2 text-white disabled:opacity-50"
          onClick={upload}
          disabled={loading || !text.trim() || !actorId}
        >
          Upload
        </button>
        {sourceId && <p data-testid="source-id" className="mt-1 text-sm text-gray-600">Source: {sourceId}</p>}
      </section>

      {blocks.length > 0 && (
        <section>
          <h2 className="mb-2 text-lg font-semibold">2. Source-linked process draft</h2>
          <p data-testid="draft-status" className="mb-2 text-sm">Status: {status}</p>
          <ul className="space-y-1">
            {blocks.map((b) => (
              <li key={b.blockId} data-testid={`block-${b.blockIndex}`} className="rounded border p-2 text-sm">
                <span className="font-mono text-xs text-gray-500">[{b.spanStart}–{b.spanEnd}]</span>{' '}
                {b.text}
              </li>
            ))}
          </ul>
        </section>
      )}

      {blocks.length > 1 && !confirmed && (
        <section>
          <h2 className="mb-2 text-lg font-semibold">3. Correct a connection</h2>
          <div className="flex gap-2">
            <select
              data-testid="conn-from"
              className="rounded border p-1"
              onChange={(e) => {
                const from = Number(e.target.value);
                const to = connections[0]?.to ?? 1;
                setConnections([{ from, to }]);
              }}
            >
              {blocks.map((b) => (
                <option key={b.blockId} value={b.blockIndex}>Step {b.blockIndex + 1}</option>
              ))}
            </select>
            <span className="self-center">→</span>
            <select
              data-testid="conn-to"
              className="rounded border p-1"
              onChange={(e) => {
                const to = Number(e.target.value);
                const from = connections[0]?.from ?? 0;
                setConnections([{ from, to }]);
              }}
            >
              {blocks.map((b) => (
                <option key={b.blockId} value={b.blockIndex}>Step {b.blockIndex + 1}</option>
              ))}
            </select>
            <button
              data-testid="correct-btn"
              className="rounded bg-amber-600 px-3 py-1 text-white disabled:opacity-50"
              onClick={correct}
              disabled={loading}
            >
              Apply correction
            </button>
          </div>
        </section>
      )}

      {blocks.length > 0 && !confirmed && (
        <section>
          <h2 className="mb-2 text-lg font-semibold">4. Confirm scoped draft</h2>
          <button
            data-testid="confirm-btn"
            className="rounded bg-green-600 px-3 py-1 text-white disabled:opacity-50"
            onClick={confirm}
            disabled={loading}
          >
            Confirm draft
          </button>
        </section>
      )}

      {confirmed && (
        <section>
          <h2 className="mb-2 text-lg font-semibold">4. Ask a connected question</h2>
          <input
            data-testid="question-input"
            className="w-full rounded border p-2"
            placeholder="e.g. Where can the handoff between licensing and production fail?"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
          />
          <div className="mt-2 flex gap-2">
            <button
              data-testid="ask-btn"
              className="rounded bg-blue-600 px-4 py-2 text-white disabled:opacity-50"
              onClick={ask}
              disabled={loading || !question.trim()}
            >
              Ask
            </button>
            {runId && (
              <button
                data-testid="refresh-btn"
                className="rounded border px-4 py-2"
                onClick={loadRun}
              >
                Refresh answer
              </button>
            )}
          </div>
        </section>
      )}

      {answer && (
        <section data-testid="answer-section">
          <p data-testid="answer-method" className="mb-2 text-sm text-amber-800">
            {answer.evidenceGraph
              ? answer.evidenceStatus === 'no_source_evidence'
                ? `Graph evidence answer: searched ${answer.evidenceGraph.corpus_source_count} original documents; no supporting source evidence found.`
                : `Graph evidence answer citing ${answer.evidenceGraph.cited_source_count} of ${answer.evidenceGraph.corpus_source_count} original documents.`
              : answer.holistic
              ? `Connected answer using ${answer.holistic.distinct_original_count ?? answer.holistic.source_count} original documents; reported source guidance.`
              : 'Historical answer from the earlier method — excluded from corrected pilot grading.'}
          </p>
          <h2 className="mb-2 text-lg font-semibold">Answer</h2>
          <div data-testid="answer-text" className="whitespace-pre-wrap rounded border p-3">
            {answer.answerText}
          </div>
          {answer.citations.length > 0 && (
            <div data-testid="citations" className="mt-2">
              <h3 className="font-semibold">Citations</h3>
              <ul className="space-y-1">
                {answer.citations.map((c, i) => (
                  <li key={i} data-testid={`citation-${i}`} className="rounded bg-gray-50 p-2 text-sm">
                    <span className="font-mono text-xs">[{c.spanStart}–{c.spanEnd}]</span> {c.quote}
                  </li>
                ))}
              </ul>
            </div>
          )}
          {answer.hypothetical && (
            <div data-testid="hypothetical" className="mt-2 rounded border border-dashed border-amber-400 bg-amber-50 p-3">
              <h3 className="font-semibold">{answer.hypothetical.label}</h3>
              <p className="text-sm">{answer.hypothetical.description}</p>
              <p className="mt-1 text-sm"><strong>Measure:</strong> {answer.hypothetical.measure}</p>
              <p className="text-sm"><strong>Missing inputs:</strong> {answer.hypothetical.missingInputs.join(', ')}</p>
            </div>
          )}
        </section>
      )}
    </div>
  );
}
